// src/components/Main.jsx
import React, { useState, useCallback, useEffect } from "react";
import "./Main.css";

import Header from "../header/Header";
import Login from "../signIn/Login";
import SignUp from "../signUp/SignUp";
import SpaceBackground from "../background/SpaceBackground";
import M_Main from "../manager/M_Main";
import Introduction from "../etcView/Introduction";
import Tutorial from "../etcView/Tutorial";
import Example from "../etcView/Example";
import Inquiries from "../etcView/Inquiries";

const CONTEXT_PATH = "/MemorySpace";
// ✅ API 공통 prefix
const API_BASE = `${CONTEXT_PATH}/api`;

const stripContextPath = (pathname) => {
  if (!pathname.startsWith(CONTEXT_PATH)) return pathname || "/";
  let stripped = pathname.slice(CONTEXT_PATH.length);
  if (stripped === "" || stripped === "/" || stripped === "/index.html")
    return "/";
  return stripped.startsWith("/") ? stripped : `/${stripped}`;
};

// ✅ 실제 관리자 페이지: M_Main을 감싸는 래퍼
const ManagerPage = ({ nickname }) => {
  return <M_Main nickname={nickname} />;
};

const Main = () => {
  // ⭐ 로그인 상태 관리
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [nickname, setNickname] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const initialPath = stripContextPath(window.location.pathname || "/");
  const [currentPage, setCurrentPage] = useState(initialPath);

  const handleOpenLogin = () => setIsLoginModalOpen(true);
  const handleCloseLogin = () => setIsLoginModalOpen(false);

  // ✅ 로그인 성공시 호출되는 함수 (Login.jsx → Main.jsx)
  //    data 예시: { success:true, userId:"", nickname:"", role:"ADMIN" }
  const handleLoginSuccess = (data) => {
    const displayName = data.nickname || data.userId || "";
    const adminFlag = data.role === "ADMIN";

    setIsLoggedIn(true);
    setNickname(displayName);
    setIsAdmin(adminFlag);

    // 관리자면 관리자 페이지, 아니면 메인
    if (adminFlag) {
      navigate("/manager");
    } else {
      navigate("/");
    }
  };

  // ✅ 로그아웃 처리 함수 (Header → Main)
  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE}/logout`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
    } catch (e) {
      console.error("로그아웃 요청 실패:", e);
    } finally {
      setIsLoggedIn(false);
      setNickname("");
      setIsAdmin(false);
      setIsLoginModalOpen(false);

      const logicalPath = "/";
      const fullPath = `${CONTEXT_PATH}/index.html`;
      window.history.pushState({}, "", fullPath);
      setCurrentPage(logicalPath);
    }
  };

  // ✅ 새로고침 했을 때 서버 세션 기준으로 로그인 상태 복원
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await fetch(`${API_BASE}/auth/me`, {
          method: "GET",
          headers: {
            Accept: "application/json",
          },
        });

        if (!res.ok) {
          // 401 같은 경우 → 비로그인 상태
          return;
        }

        // 예시 응답: { loggedIn:true, userId:"", nickname:"", role:"USER" }
        const data = await res.json();
        if (data.loggedIn) {
          setIsLoggedIn(true);
          setNickname(data.nickname || data.userId || "");
          const adminFlag = data.role === "ADMIN";
          setIsAdmin(adminFlag);

          // 만약 현재 주소가 /manager인데 admin이 아니면 강제로 홈으로
          const logicalPath = stripContextPath(window.location.pathname || "/");
          if (logicalPath === "/manager" && !adminFlag) {
            navigate("/");
          } else {
            setCurrentPage(logicalPath);
          }
        }
      } catch (e) {
        console.error("로그인 상태 확인 실패:", e);
      }
    };

    checkAuth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const navigate = useCallback((path, options = {}) => {
    const logicalPath = path.startsWith("/") ? path : `/${path}`;
    const fullPath =
      logicalPath === "/"
        ? `${CONTEXT_PATH}/index.html`
        : `${CONTEXT_PATH}${logicalPath}`;

    window.history.pushState({}, "", fullPath);
    setCurrentPage(logicalPath);

    if (options.openLogin) setIsLoginModalOpen(true);
    else setIsLoginModalOpen(false);
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      const pathname = stripContextPath(window.location.pathname);

      // 뒤로가기 등으로 /manager 왔는데 권한 없으면 홈으로
      if (pathname === "/manager" && !isAdmin) {
        const fullPath = `${CONTEXT_PATH}/index.html`;
        window.history.replaceState({}, "", fullPath);
        setCurrentPage("/");
      } else {
        setCurrentPage(pathname);
      }

      setIsLoginModalOpen(false);
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, [isAdmin]);

  const renderContent = () => {
    switch (currentPage) {
      case "/signup":
        return <SignUp navigate={navigate} />;

      case "/manager":
        return <ManagerPage nickname={nickname} />;

      // ⭐ 추가된 4개 라우트
      case "/introduction":
        return <Introduction />;

      case "/tutorial":
        return <Tutorial />;

      case "/example":
        return <Example />;

      case "/inquiries":
        return <Inquiries />;

      case "/":
      default:
        return (
          <main className="main-wrapper">
            <SpaceBackground navigate={navigate} />
          </main>
        );
    }
  };

  return (
    <div className="app-root">
      {currentPage !== "/manager" && (
        <Header
          onLoginClick={handleOpenLogin}
          navigate={navigate}
          isLoggedIn={isLoggedIn}
          nickname={nickname}
          onLogout={handleLogout} // ✅ 로그아웃 콜백 전달
        />
      )}

      {renderContent()}

      <Login
        isOpen={isLoginModalOpen}
        onClose={handleCloseLogin}
        navigate={navigate}
        onLoginSuccess={handleLoginSuccess} // ⭐ 로그인 성공 callback (role 포함 data)
      />
    </div>
  );
};

export default Main;
