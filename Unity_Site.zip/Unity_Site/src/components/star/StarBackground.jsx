// src/components/star/StarBackground.jsx
import React, { useEffect, useRef, useState } from "react";
import "../background/SpaceBackground.css";
import "./StarSidebar.css";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;
const MAX_STAR_NAME_LENGTH = 15;
const MAX_STARS = 12;

export default function StarBackground({ navigate }) {
  const spaceRef = useRef(null);
  const sceneRef = useRef(null);
  const smallLayerRef = useRef(null);
  const bigLayerRef = useRef(null);
  const tooltipRef = useRef(null);
  const warpLayerRef = useRef(null);
  const zoomLayerRef = useRef(null);

  const emitterTimerRef = useRef(null);
  const emitterEndTimerRef = useRef(null);
  const resizeTimerRef = useRef(null);

  const [userStars, setUserStars] = useState([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newStarName, setNewStarName] = useState("");
  
  // 별 관리 모달 (수정/삭제)
  const [selectedStar, setSelectedStar] = useState(null);
  const [isManaging, setIsManaging] = useState(false);
  const [editName, setEditName] = useState("");

  const clamp = (v, min, max) => Math.min(Math.max(v, min), max);

  // ===== Tooltip =====
  const showTooltip = (x, y, html) => {
    const tip = tooltipRef.current;
    const spaceEl = spaceRef.current;
    if (!tip || !spaceEl) return;
    tip.innerHTML = html;
    tip.classList.add("show");
    requestAnimationFrame(() => {
      const W = spaceEl.clientWidth || window.innerWidth;
      const H = spaceEl.clientHeight || window.innerHeight;
      const maxLeft = W - (tip.offsetWidth || 0) - 8;
      const maxTop = H - (tip.offsetHeight || 0) - 8;
      tip.style.left = clamp(x + 28, 8, maxLeft) + "px";
      tip.style.top = clamp(y - 10, 8, maxTop) + "px";
    });
  };

  const hideTooltip = () => {
    const t = tooltipRef.current;
    if (t) t.classList.remove("show");
  };

  const distanceToEdgeFrom = (angleRad, W, H, x0, y0) => {
    const dx = Math.cos(angleRad);
    const dy = Math.sin(angleRad);
    const tVals = [];
    if (dx !== 0) {
      const tx1 = (0 - x0) / dx;
      if (tx1 > 0) tVals.push(tx1);
      const tx2 = (W - x0) / dx;
      if (tx2 > 0) tVals.push(tx2);
    }
    if (dy !== 0) {
      const ty1 = (0 - y0) / dy;
      if (ty1 > 0) tVals.push(ty1);
      const ty2 = (H - y0) / dy;
      if (ty2 > 0) tVals.push(ty2);
    }
    const t = Math.min(...tVals);
    return Number.isFinite(t) ? t : Math.hypot(W, H);
  };

  // ===== Warp Effect =====
  const startWarp = () => {
    const spaceEl = spaceRef.current;
    const warpLayer = warpLayerRef.current;
    if (!spaceEl || !warpLayer) return;
    stopWarp();

    const scene = sceneRef.current;
    if (scene) scene.classList.add("scene-zooming");

    const W = spaceEl.clientWidth;
    const H = spaceEl.clientHeight;
    const cx = W / 2;
    const cy = H / 2;
    const Rmin = Math.min(W, H) * 0.1;
    const band = Math.min(W, H) * 0.08;

    const EMIT_BATCH = 20;
    const EMIT_EVERY_MS = 140;
    const MAX_EMIT_MS = 2000;
    const OVERSHOOT = 200;

    const emitBatch = () => {
      for (let i = 0; i < EMIT_BATCH; i++) {
        const span = document.createElement("span");
        span.className = "streak";
        const angleDeg = Math.random() * 360;
        const angleRad = (angleDeg * Math.PI) / 180;
        const rStart = Rmin + Math.random() * band;
        const x0 = cx + Math.cos(angleRad) * rStart;
        const y0 = cy + Math.sin(angleRad) * rStart;
        const reach = distanceToEdgeFrom(angleRad, W, H, x0, y0) + OVERSHOOT;
        const dur = 1500 + Math.random() * 800;
        const delay = Math.random() * 80;
        span.style.setProperty("--angle", angleDeg + "deg");
        span.style.setProperty("--len", reach.toFixed(2) + "px");
        span.style.setProperty("--dur", Math.round(dur) + "ms");
        span.style.setProperty("--delay", Math.round(delay) + "ms");
        span.style.backgroundImage =
          "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.9) 30%, rgba(255,255,255,0) 100%)";
        span.style.left = x0 + "px";
        span.style.top = y0 + "px";
        warpLayer.appendChild(span);
        setTimeout(() => span.remove(), Math.round(delay + dur + 60));
      }
    };
    emitBatch();
    emitterTimerRef.current = setInterval(emitBatch, EMIT_EVERY_MS);
    emitterEndTimerRef.current = setTimeout(() => {
      stopWarp();
      if (scene) scene.classList.remove("scene-zooming");
    }, MAX_EMIT_MS);
  };

  const stopWarp = () => {
    if (emitterTimerRef.current) clearInterval(emitterTimerRef.current);
    if (emitterEndTimerRef.current) clearTimeout(emitterEndTimerRef.current);
    emitterTimerRef.current = emitterEndTimerRef.current = null;
    if (warpLayerRef.current) warpLayerRef.current.textContent = "";
  };

  // ===== Zoom animation =====
  const zoomFromStar = (starEl, starData) => {
    const spaceEl = spaceRef.current;
    const zoomLayer = zoomLayerRef.current;
    if (!starEl || !spaceEl || !zoomLayer) return;

    const sRect = starEl.getBoundingClientRect();
    const pRect = spaceEl.getBoundingClientRect();
    const cx = sRect.left - pRect.left + sRect.width / 2;
    const cy = sRect.top - pRect.top + sRect.height / 2;
    const centerX = pRect.width / 2;
    const centerY = pRect.height / 2;
    const dx = centerX - cx;
    const dy = centerY - cy;

    starEl.style.setProperty("--mx", `${dx}px`);
    starEl.style.setProperty("--my", `${dy}px`);

    starEl.style.transition = "transform 0.8s ease-out";
    starEl.style.transform = `translate(${dx}px, ${dy}px) scale(1)`;

    setTimeout(() => {
      starEl.classList.add("zooming");
      startWarp();

      const burst = document.createElement("div");
      burst.className = "zoom-burst";
      burst.style.left = centerX + "px";
      burst.style.top = centerY + "px";
      zoomLayer.appendChild(burst);
      setTimeout(() => burst.remove(), 700);

      setTimeout(() => {
        starEl.style.transition = "transform 0.8s ease-in";
        starEl.style.transform = "translate(0,0) scale(1)";
        starEl.style.setProperty("--mx", `0px`);
        starEl.style.setProperty("--my", `0px`);
        setTimeout(() => {
          starEl.classList.remove("zooming");
          starEl.style.transition = "";

          if (navigate && starData) {
            navigate(`/star/${starData.id}`);
          }
        }, 800);
      }, 1800);
    }, 800);
  };

  // ===== Fetch user stars =====
  const fetchUserStars = async () => {
    try {
      const response = await fetch(`${API_BASE}/star/list`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        setUserStars(data.stars || []);
        console.log("User stars loaded:", data.stars);
      } else {
        console.error("Failed to fetch stars:", data.message);
        setUserStars([]);
      }
    } catch (error) {
      console.error("Failed to fetch user stars:", error);
      setUserStars([]);
    }
  };

  // ===== Create new star =====
  const handleCreateStar = async () => {
    const trimmedName = newStarName.trim();
    if (!trimmedName) {
      alert("별 이름을 입력해주세요.");
      return;
    }

    if (trimmedName.length > MAX_STAR_NAME_LENGTH) {
      alert(`별 이름은 ${MAX_STAR_NAME_LENGTH}자 이내로 입력해주세요.`);
      return;
    }

    if (userStars.length >= MAX_STARS) {
      alert(`별은 최대 ${MAX_STARS}개까지만 생성 가능합니다.`);
      setIsCreating(false);
      return;
    }

    try {
      const formData = new URLSearchParams();
      formData.append('name', trimmedName);

      const response = await fetch(`${API_BASE}/star/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        setNewStarName("");
        setIsCreating(false);
        fetchUserStars();
      } else {
        alert(data.message || "별 생성에 실패했습니다.");
      }
    } catch (error) {
      console.error("Failed to create star:", error);
      alert("서버 연결 오류");
    }
  };

  // ===== Update star name =====
  const handleUpdateStar = async () => {
    const trimmedName = editName.trim();
    if (!trimmedName) {
      alert("별 이름을 입력해주세요.");
      return;
    }

    if (trimmedName.length > MAX_STAR_NAME_LENGTH) {
      alert(`별 이름은 ${MAX_STAR_NAME_LENGTH}자 이내로 입력해주세요.`);
      return;
    }

    try {
      const formData = new URLSearchParams();
      formData.append('starId', selectedStar.id);
      formData.append('name', trimmedName);

      const response = await fetch(`${API_BASE}/star/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        setIsManaging(false);
        setSelectedStar(null);
        fetchUserStars();
      } else {
        alert(data.message || "별 이름 수정에 실패했습니다.");
      }
    } catch (error) {
      console.error("Failed to update star:", error);
      alert("서버 연결 오류");
    }
  };

  // ===== Delete star =====
  const handleDeleteStar = async () => {
    if (!window.confirm(`별 '${selectedStar.name}'을(를) 정말 삭제하시겠습니까?`)) {
      return;
    }

    try {
      const formData = new URLSearchParams();
      formData.append('starId', selectedStar.id);

      const response = await fetch(`${API_BASE}/star/delete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString()
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.success) {
        setIsManaging(false);
        setSelectedStar(null);
        fetchUserStars();
      } else {
        alert(data.message || "별 삭제에 실패했습니다.");
      }
    } catch (error) {
      console.error("Failed to delete star:", error);
      alert("서버 연결 오류");
    }
  };

  // ===== Open manage modal =====
  const handleOpenManage = (star) => {
    setSelectedStar(star);
    setEditName(star.name);
    setIsManaging(true);
  };

  // ===== Generate stars =====
  const generateStars = () => {
    const spaceEl = spaceRef.current;
    const smallLayer = smallLayerRef.current;
    const bigLayer = bigLayerRef.current;
    if (!spaceEl || !smallLayer || !bigLayer) return;

    smallLayer.textContent = "";
    bigLayer.textContent = "";
    hideTooltip();

    const W = spaceEl.clientWidth || window.innerWidth;
    const H = spaceEl.clientHeight || window.innerHeight;

    const SMALL_COUNT = 200;
    const BIG_MIN_DIST = 120;
    const EDGE_MARGIN = 200;
    const bigStars = [];

    const isFar = (x, y, list, min) =>
      list.every((p) => Math.hypot(x - p.x, y - p.y) > min);

    const marginX = Math.min(EDGE_MARGIN, Math.max(0, W / 4));
    const marginY = Math.min(EDGE_MARGIN, Math.max(0, H / 4));
    const minX = marginX;
    const maxX = Math.max(minX + 1, W - marginX);
    const minY = marginY;
    const maxY = Math.max(minY + 1, H - marginY);

    userStars.forEach((starData) => {
      let x = 0;
      let y = 0;
      let tries = 0;
      do {
        x = minX + Math.random() * (maxX - minX);
        y = minY + Math.random() * (maxY - minY);
      } while (!isFar(x, y, bigStars, BIG_MIN_DIST) && tries++ < 400);

      const s = document.createElement("div");
      s.className = "big-star";
      s.style.left = x + "px";
      s.style.top = y + "px";

      const html = `<div class="tip-title">${starData.name}</div><div class="tip-desc">클릭하여 메모리 보기</div>`;
      
      s.addEventListener("mouseenter", (e) =>
        showTooltip(e.clientX, e.clientY, html)
      );
      s.addEventListener("mousemove", (e) =>
        showTooltip(e.clientX, e.clientY, html)
      );
      s.addEventListener("mouseleave", hideTooltip);

      s.addEventListener("click", () => zoomFromStar(s, starData));

      bigLayer.appendChild(s);
      bigStars.push({ x, y });
    });

    for (let i = 0; i < SMALL_COUNT; i++) {
      const s = document.createElement("div");
      s.className = "small-star";
      const size = 1.5 + Math.random() * 3;
      const opacity = 0.5 + Math.random() * 0.5;
      s.style.width = size + "px";
      s.style.height = size + "px";
      s.style.opacity = opacity;
      s.style.left = Math.random() * W + "px";
      s.style.top = Math.random() * H + "px";
      smallLayer.appendChild(s);
    }
  };

  useEffect(() => {
    fetchUserStars();
  }, []);

  useEffect(() => {
    if (userStars.length >= 0) {
      generateStars();
    }
  }, [userStars]);

  useEffect(() => {
    const handleResize = () => {
      if (resizeTimerRef.current) {
        clearTimeout(resizeTimerRef.current);
      }
      resizeTimerRef.current = setTimeout(() => {
        generateStars();
      }, 200);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      stopWarp();
      window.removeEventListener("resize", handleResize);
      if (resizeTimerRef.current) {
        clearTimeout(resizeTimerRef.current);
      }
    };
  }, [userStars]);

  return (
    <div ref={spaceRef} className="space" aria-hidden="true">
      <div ref={sceneRef} className="scene">
        <div className="nebula" />
        <div ref={smallLayerRef} className="layer small-layer" />
        <div ref={bigLayerRef} className="layer big-layer" />
      </div>
      <div ref={warpLayerRef} className="warp-layer" />
      <div ref={zoomLayerRef} className="zoom-layer" />
      <div ref={tooltipRef} className="tooltip" />

      {/* 왼쪽 사이드바 */}
      <div className="star-sidebar">
        <h3 className="star-sidebar-title">My Stars ({userStars.length}/{MAX_STARS})</h3>
        <div className="star-list">
          {userStars.map((star) => (
            <button 
              key={star.id} 
              className="star-item"
              onClick={() => handleOpenManage(star)}
            >
              ⭐ {star.name}
            </button>
          ))}
        </div>
      </div>

      {/* 별 생성 버튼 */}
      {userStars.length < MAX_STARS && (
        <button 
          className="create-star-button" 
          onClick={() => setIsCreating(true)}
          aria-label="새 별 만들기"
        >
          +
        </button>
      )}

      {/* 별 생성 모달 */}
      {isCreating && (
        <div className="star-modal-overlay" onClick={() => setIsCreating(false)}>
          <div className="star-modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>새 별 만들기</h2>
            <input
              type="text"
              placeholder="별의 이름을 입력하세요"
              value={newStarName}
              onChange={(e) => setNewStarName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleCreateStar();
              }}
              maxLength={MAX_STAR_NAME_LENGTH}
            />
            <p className="char-count">{newStarName.length}/{MAX_STAR_NAME_LENGTH}</p>
            <div className="modal-actions">
              <button className="confirm-button" onClick={handleCreateStar}>확인</button>
              <button className="cancel-button" onClick={() => setIsCreating(false)}>취소</button>
            </div>
          </div>
        </div>
      )}

      {/* 별 관리 모달 (수정/삭제) */}
      {isManaging && selectedStar && (
        <div className="star-modal-overlay" onClick={() => setIsManaging(false)}>
          <div className="star-modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>별 관리</h2>
            <input
              type="text"
              placeholder="새 이름을 입력하세요"
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleUpdateStar();
              }}
              maxLength={MAX_STAR_NAME_LENGTH}
            />
            <p className="char-count">{editName.length}/{MAX_STAR_NAME_LENGTH}</p>
            <div className="modal-actions">
              <button className="confirm-button" onClick={handleUpdateStar}>이름 수정</button>
              <button className="delete-button" onClick={handleDeleteStar}>삭제</button>
              <button className="cancel-button" onClick={() => setIsManaging(false)}>취소</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}