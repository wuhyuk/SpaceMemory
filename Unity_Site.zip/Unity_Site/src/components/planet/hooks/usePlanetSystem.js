// src/planet/hooks/usePlanetSystem.js
import { useRef, useState, useEffect } from "react";

export default function usePlanetSystem() {
  /* -----------------------------------------------------
     Refs
  ----------------------------------------------------- */
  const planetsRef = useRef([]);
  const labelRefs = useRef([]);
  const isPausedRef = useRef(false);
  const nextId = useRef(0);
  const containerRef = useRef(null);

  /* -----------------------------------------------------
     UI States
  ----------------------------------------------------- */
  const [planetList, setPlanetList] = useState([]);
  const [hoveredListPlanet, setHoveredListPlanet] = useState(null);

  // ✅ 기존: 행성 추가 팝업
  const [popupOpen, setPopupOpen] = useState(false);

  // ✅ 추가: 행성 편집 팝업
  const [planetEditPopup, setPlanetEditPopup] = useState(null); // { planet } | null

  // ✅ 미디어 모달(기존 mediaPopup)
  const [mediaPopup, setMediaPopup] = useState(null);

  /* -----------------------------------------------------
     Inputs for AddPlanet
  ----------------------------------------------------- */
  const [inputName, setInputNameState] = useState("");
  const [inputFile, setInputFile] = useState([]);
  const [inputTag, setInputTag] = useState("");
  const [tags, setTags] = useState([]);
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");

  const setInputName = (name) => {
    if (typeof name === "string" && name.length > 7) {
      name = name.substring(0, 7);
    }
    setInputNameState(name);
  };

  /* -----------------------------------------------------
     Inputs for MediaAddPopup
  ----------------------------------------------------- */
  const [mediaDescription, setMediaDescription] = useState("");
  const [mediaLocation, setMediaLocation] = useState("");

  const fileInputRef = useRef(null);

  /* -----------------------------------------------------
     Planet Ref Sync
  ----------------------------------------------------- */
  useEffect(() => {
    const sortedPlanetList = [...planetList].sort((a, b) => a.id - b.id);
    planetsRef.current = sortedPlanetList;

    console.log("--- Planet List Updated ---");
    console.log(`현재 행성 개수: ${planetList.length}`);
    console.log("행성 ID 목록:", planetList.map((p) => p.id).sort((a, b) => a - b));
    console.log(planetList);
    console.log("--------------------------");
  }, [planetList]);

  /* -----------------------------------------------------
     Find Next Planet ID
  ----------------------------------------------------- */
  const findNextPlanetId = (currentPlanetList) => {
    const existingIds = currentPlanetList.map((p) => p.id).sort((a, b) => a - b);

    let nextIdLocal = 1;
    for (const id of existingIds) {
      if (id > nextIdLocal) return nextIdLocal;
      nextIdLocal++;
    }
    return nextIdLocal;
  };

  /* -----------------------------------------------------
     Add Planet
  ----------------------------------------------------- */
  const addPlanet = (name, files) => {
    const newId = findNextPlanetId(planetList);

    // 프리뷰용 파일 정규화
    const normalizedPreviewFiles = files.map((it) => ({
      url: it.url,
      mediaType: it.mediaType,
      liked: false,
      likedAt: null,
      starred: false,
      starredAt: null,
      reported: false,
      reportedAt: null,
      reportCount: 0,
    }));

    const getPlanetColorById = (id) => {
      const hue = (newId * 137) % 360;
      const saturation = 80 + (id % 15);
      const lightness = 60 + (id % 15);
      return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
    };

    const newPlanet = {
      id: newId,
      r: 10 + newId * 4,
      orbit: newId * 100 + 150,
      speed: 0.0005 / newId,
      color: getPlanetColorById(newId),
      angle: Math.random() * Math.PI * 2,
      name,

      previewFiles: normalizedPreviewFiles,
      mediaList: [],

      preview: normalizedPreviewFiles?.[0]?.url || null,

      screenX: 0,
      screenY: 0,
    };

    setPlanetList((prev) => [...prev, newPlanet]);
    return true;
  };

  /* -----------------------------------------------------
     ✅ Update Planet (이름/썸네일)
  ----------------------------------------------------- */
  const updatePlanet = (planetId, newName, newFile) => {
    // newFile이 File이면 objectURL로 프리뷰 생성
    let newPreviewUrl = null;
    let newPreviewFiles = null;

    if (newFile instanceof File) {
      newPreviewUrl = URL.createObjectURL(newFile);
      const mediaType = newFile.type?.startsWith("video") ? "video" : "image";

      newPreviewFiles = [
        {
          url: newPreviewUrl,
          mediaType,
          liked: false,
          likedAt: null,
          starred: false,
          starredAt: null,
          reported: false,
          reportedAt: null,
          reportCount: 0,
        },
      ];
    }

    setPlanetList((prev) =>
      prev.map((p) => {
        if (p.id !== planetId) return p;

        const updated = {
          ...p,
          name: typeof newName === "string" ? newName : p.name,
        };

        // 썸네일 파일이 바뀐 경우에만 갱신
        if (newPreviewFiles) {
          updated.previewFiles = newPreviewFiles;
          updated.preview = newPreviewUrl;
        }

        return updated;
      })
    );

    // 열려있는 mediaPopup도 즉시 반영
    setMediaPopup((prev) => {
      if (!prev || prev.planet.id !== planetId) return prev;

      const updatedPlanet = {
        ...prev.planet,
        name: typeof newName === "string" ? newName : prev.planet.name,
      };

      if (newPreviewFiles) {
        updatedPlanet.previewFiles = newPreviewFiles;
        updatedPlanet.preview = newPreviewUrl;
      }

      return { ...prev, planet: updatedPlanet };
    });
  };

  /* -----------------------------------------------------
     Delete Planet
  ----------------------------------------------------- */
  const deletePlanet = (planetId) => {
    console.log(`🗑️ 행성 삭제 시작: ID ${planetId}`);

    setHoveredListPlanet(null);
    setMediaPopup(null);
    setPlanetEditPopup(null);
    isPausedRef.current = false;

    setPlanetList((prevList) => {
      const newList = prevList.filter((p) => p.id !== planetId);
      console.log(`✅ 삭제 완료. 남은 행성: ${newList.length}개`);
      console.log(`남은 행성 ID:`, newList.map((p) => p.id));
      return newList;
    });
  };

  /* -----------------------------------------------------
     Add Media
  ----------------------------------------------------- */
  const addMediaToPlanet = (planetId, files) => {
    console.log("🎬 addMediaToPlanet 호출됨");
    console.log("전달된 files:", files);

    const normalizedMedia = files.map((file) => {
      const fileUrl = file.url || file.media || URL.createObjectURL(file);
      const fileType =
        file.mediaType || (file.type?.startsWith("video") ? "video" : "image");

      return {
        ...file,
        url: fileUrl,
        mediaType: fileType,
        liked: false,
        likedAt: null,
        starred: false,
        starredAt: null,
        reported: false,
        reportedAt: null,
        reportCount: 0,
      };
    });

    setPlanetList((prevList) => {
      return prevList.map((p) => {
        if (p.id !== planetId) return p;

        const updatedPlanet = { ...p };
        updatedPlanet.mediaList = [...(p.mediaList || []), ...normalizedMedia];

        // preview는 mediaList의 첫 항목으로 유지(기존 로직)
        updatedPlanet.preview = updatedPlanet.mediaList[0]?.url || p.preview || null;

        return updatedPlanet;
      });
    });

    // mediaPopup 즉시 반영
    setMediaPopup((prev) => {
      if (!prev || prev.planet.id !== planetId) return prev;
      return {
        ...prev,
        planet: {
          ...prev.planet,
          mediaList: [...(prev.planet.mediaList || []), ...normalizedMedia],
        },
      };
    });
  };

  const updatePlanetMeta = (planetId, { tags, description, location }) => {
    setPlanetList((prev) =>
      prev.map((p) => {
        if (p.id !== planetId) return p;
        return {
          ...p,
          tags: tags ?? p.tags,
          description: description ?? p.description,
          location: location ?? p.location,
        };
      })
    );

    setMediaPopup((prev) => {
      if (!prev || prev.planet.id !== planetId) return prev;
      return {
        ...prev,
        planet: {
          ...prev.planet,
          tags: tags ?? prev.planet.tags ?? [],
          description: description ?? prev.planet.description ?? "",
          location: location ?? prev.planet.location ?? "",
        },
      };
    });
  };

  const updateMediaMeta = (planetId, mediaIndex, meta) => {
    setPlanetList((prevList) =>
      prevList.map((p) => {
        if (p.id !== planetId) return p;

        const updatedMediaList = [...p.mediaList];
        updatedMediaList[mediaIndex] = {
          ...updatedMediaList[mediaIndex],
          ...meta,
        };

        return { ...p, mediaList: updatedMediaList };
      })
    );

    setMediaPopup((prev) => {
      if (!prev || prev.planet.id !== planetId) return prev;

      const updatedMediaList = [...prev.planet.mediaList];
      updatedMediaList[mediaIndex] = {
        ...updatedMediaList[mediaIndex],
        ...meta,
      };

      return {
        ...prev,
        planet: { ...prev.planet, mediaList: updatedMediaList },
      };
    });
  };

  /* -----------------------------------------------------
     Delete Media From Planet
  ----------------------------------------------------- */
  const deleteMediaFromPlanet = (planetId, mediaIndex) => {
    let updatedPlanet = null;

    setPlanetList((prevList) => {
      const target = prevList.find((p) => p.id === planetId);
      if (!target) return prevList;

      const newMediaList = target.mediaList.filter((_, idx) => idx !== mediaIndex);

      const newList = prevList.map((p) => {
        if (p.id !== planetId) return p;

        updatedPlanet = {
          ...p,
          mediaList: newMediaList,
          preview: newMediaList[0]?.url || null,
        };
        return updatedPlanet;
      });

      return newList;
    });

    setMediaPopup((prevPopup) => {
      if (!prevPopup || prevPopup.planet.id !== planetId) return prevPopup;

      if (updatedPlanet) {
        return { planet: updatedPlanet, zoomIndex: null };
      }
      return prevPopup;
    });
  };

  /* -----------------------------------------------------
     Toggle Like / Star / Report
  ----------------------------------------------------- */
  const toggleLike = (planetId, mediaIndex) => {
    setPlanetList((prevList) =>
      prevList.map((p) => {
        if (p.id !== planetId) return p;
        return {
          ...p,
          mediaList: p.mediaList.map((m, idx) => {
            if (idx !== mediaIndex) return m;
            const next = !m.liked;
            return { ...m, liked: next, likedAt: next ? new Date().toISOString() : null };
          }),
        };
      })
    );

    setMediaPopup((prev) => {
      if (!prev || prev.planet.id !== planetId) return prev;
      return {
        ...prev,
        planet: {
          ...prev.planet,
          mediaList: prev.planet.mediaList.map((m, idx) => {
            if (idx !== mediaIndex) return m;
            const next = !m.liked;
            return { ...m, liked: next, likedAt: next ? new Date().toISOString() : null };
          }),
        },
      };
    });
  };

  const toggleStar = (planetId, mediaIndex) => {
    setPlanetList((prevList) =>
      prevList.map((p) => {
        if (p.id !== planetId) return p;
        return {
          ...p,
          mediaList: p.mediaList.map((m, idx) => {
            if (idx !== mediaIndex) return m;
            const next = !m.starred;
            return { ...m, starred: next, starredAt: next ? new Date().toISOString() : null };
          }),
        };
      })
    );

    setMediaPopup((prev) => {
      if (!prev || prev.planet.id !== planetId) return prev;
      return {
        ...prev,
        planet: {
          ...prev.planet,
          mediaList: prev.planet.mediaList.map((m, idx) => {
            if (idx !== mediaIndex) return m;
            const next = !m.starred;
            return { ...m, starred: next, starredAt: next ? new Date().toISOString() : null };
          }),
        },
      };
    });
  };

  const reportMedia = (planetId, mediaIndex, reason) => {
    setPlanetList((prevList) =>
      prevList.map((p) => {
        if (p.id !== planetId) return p;
        return {
          ...p,
          mediaList: p.mediaList.map((m, idx) => {
            if (idx !== mediaIndex) return m;
            return {
              ...m,
              reported: true,
              reportedAt: new Date().toISOString(),
              reportCount: (m.reportCount || 0) + 1,
              reportReason: reason,
              reportHistory: [
                ...(m.reportHistory || []),
                { reason, timestamp: new Date().toISOString() },
              ],
            };
          }),
        };
      })
    );

    setMediaPopup((prev) => {
      if (!prev || prev.planet.id !== planetId) return prev;
      return {
        ...prev,
        planet: {
          ...prev.planet,
          mediaList: prev.planet.mediaList.map((m, idx) => {
            if (idx !== mediaIndex) return m;
            return {
              ...m,
              reported: true,
              reportedAt: new Date().toISOString(),
              reportCount: (m.reportCount || 0) + 1,
              reportReason: reason,
              reportHistory: [
                ...(m.reportHistory || []),
                { reason, timestamp: new Date().toISOString() },
              ],
            };
          }),
        },
      };
    });

    alert("신고가 접수되었습니다.");
  };

  /* -----------------------------------------------------
     Open/Close Helpers
  ----------------------------------------------------- */
  const closeAddPopup = () => {
    setPopupOpen(false);
    setHoveredListPlanet(null);
    isPausedRef.current = false;

    setInputFile([]);
    setInputName("");
  };

  const openPlanetEditPopup = (planet) => {
    if (!planet) return;
    setPlanetEditPopup({ planet });
    isPausedRef.current = true;
  };

  const closePlanetEditPopup = () => {
    setPlanetEditPopup(null);
    isPausedRef.current = false;
  };

  const closeMediaPopup = () => {
    setMediaPopup(null);
    setHoveredListPlanet(null);
    isPausedRef.current = false;
  };

  /* -----------------------------------------------------
     Handle File Change (AddPlanet thumbnail)
  ----------------------------------------------------- */
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);

    const previewList = files.map((file) => ({
      file,
      url: URL.createObjectURL(file),
      mediaType: file.type.startsWith("video") ? "video" : "image",
      description: "",
      location: "",
    }));

    setInputFile((prev) => [...prev, ...previewList]);
    e.target.value = "";
  };

  /* -----------------------------------------------------
     Return System
  ----------------------------------------------------- */
  return {
    containerRef,
    planetsRef,
    labelRefs,
    isPausedRef,
    nextId,

    planetList,
    hoveredListPlanet,

    popupOpen,
    planetEditPopup,

    mediaPopup,

    inputName,
    inputFile,
    inputTag,
    tags,
    description,
    location,

    mediaDescription,
    mediaLocation,

    fileInputRef,

    setPlanetList,
    setHoveredListPlanet,
    setPopupOpen,
    setMediaPopup,
    setInputName,
    setInputFile,
    setInputTag,
    setTags,
    setDescription,
    setLocation,
    setMediaDescription,
    setMediaLocation,

    addPlanet,
    updatePlanet,
    updatePlanetMeta,
    updateMediaMeta,

    deletePlanet,
    deleteMediaFromPlanet,
    addMediaToPlanet,

    handleFileChange,
    closeAddPopup,

    openPlanetEditPopup,
    closePlanetEditPopup,

    closeMediaPopup,

    toggleLike,
    toggleStar,
    reportMedia,
  };
}
