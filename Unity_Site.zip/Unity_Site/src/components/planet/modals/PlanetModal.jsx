// src/planet/modals/PlanetModal.jsx
import React, { useEffect, useRef, useState } from "react";
import "./PlanetModal.css";

export default function PlanetModal({ system }) {
  const {
    // add
    popupOpen,
    closeAddPopup,
    inputName,
    setInputName,
    inputFile,
    setInputFile,
    handleFileChange,
    fileInputRef,
    addPlanet,

    // edit
    planetEditPopup,
    closePlanetEditPopup,
    updatePlanet,
  } = system;

  // ---------- Add ----------
  const [addErrorMessage, setAddErrorMessage] = useState("");

  useEffect(() => {
    if (popupOpen) setAddErrorMessage("");
  }, [popupOpen]);

  const handleRemoveAddFile = (indexToRemove) => {
    const updatedFiles = inputFile.filter((_, idx) => idx !== indexToRemove);
    setInputFile(updatedFiles);
    if (fileInputRef.current) fileInputRef.current.value = "";
    setAddErrorMessage("");
  };

  const handleCreatePlanet = () => {
    if (!inputName.trim() || inputFile.length === 0) {
      setAddErrorMessage("이름 혹은 썸네일을 넣지 않았습니다");
      return;
    }
    if (inputFile.length > 1) {
      setAddErrorMessage("썸네일은 한개만 지정 가능합니다");
      return;
    }
    const success = addPlanet(inputName, inputFile);
    if (success) closeAddPopup();
  };

  // ---------- Edit ----------
  const planet = planetEditPopup?.planet || null;
  const [editName, setEditName] = useState("");
  const [editFile, setEditFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const editFileInputRef = useRef(null);

  useEffect(() => {
    if (!planetEditPopup || !planet) return;
    setEditName(planet.name || "");
    setPreviewUrl(planet.preview || "");
    setEditFile(null);
  }, [planetEditPopup, planet]);

  const handleThumbnailChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setEditFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleSavePlanetEdit = () => {
    if (!editName.trim()) {
      alert("행성 이름을 입력해주세요.");
      return;
    }
    updatePlanet(planet.id, editName, editFile);
    closePlanetEditPopup();
  };

  // ---------- Render ----------
  if (popupOpen) {
    return (
      <div className="popup-overlay" onClick={closeAddPopup}>
        <div className="popup-panel" onClick={(e) => e.stopPropagation()}>
          <h2 style={{ marginBottom: "6px" }}>행성 추가</h2>

          <input
            className="input-text"
            placeholder="행성 이름"
            value={inputName}
            onChange={(e) => {
              setInputName(e.target.value);
              setAddErrorMessage("");
            }}
          />

          <div className="file-select-area">
            <button
              className="file-select-button"
              onClick={() => fileInputRef.current.click()}
            >
              파일 선택
            </button>

            <input
              type="file"
              multiple
              accept="image/*,video/*"
              style={{ display: "none" }}
              ref={fileInputRef}
              onChange={(e) => {
                handleFileChange(e);
                setAddErrorMessage("");
              }}
            />

            {inputFile.length > 1 && (
              <div className="warning-box">⚠️ 썸네일은 한개만 지정 가능합니다</div>
            )}
          </div>

          <div className="preview-strip">
            {inputFile.map((m, i) => (
              <div key={i} className="preview-item">
                <div
                  className="preview-delete-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRemoveAddFile(i);
                  }}
                >
                  ×
                </div>
                {m.mediaType === "image" ? <img src={m.url} alt="" /> : <video src={m.url} muted />}
              </div>
            ))}
          </div>

          {addErrorMessage && (
            <div className="error-message-box">⛔ {addErrorMessage}</div>
          )}

          <div className="popup-buttons">
            <button className="popup-add" onClick={handleCreatePlanet}>생성</button>
            <button className="popup-close" onClick={closeAddPopup}>닫기</button>
          </div>
        </div>
      </div>
    );
  }

  if (planetEditPopup && planet) {
    return (
      <div className="planet-edit-overlay" onClick={closePlanetEditPopup}>
        <div className="planet-edit-panel" onClick={(e) => e.stopPropagation()}>
          <h3>행성 정보 수정</h3>

          <div className="edit-input-group">
            <label className="edit-label">행성 이름</label>
            <input
              className="edit-input-text"
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              placeholder="행성 이름을 입력하세요"
            />
          </div>

          <div className="edit-input-group">
            <label className="edit-label">대표 썸네일 변경</label>

            <div className="edit-thumbnail-preview">
              {previewUrl ? <img src={previewUrl} alt="Thumbnail Preview" /> : <div className="no-preview-text">No Image</div>}
            </div>

            <button className="edit-file-btn" onClick={() => editFileInputRef.current.click()}>
              파일 선택
            </button>

            <input
              type="file"
              ref={editFileInputRef}
              style={{ display: "none" }}
              accept="image/*,video/*"
              onChange={handleThumbnailChange}
            />
          </div>

          <div className="edit-actions">
            <button className="edit-cancel-btn" onClick={closePlanetEditPopup}>취소</button>
            <button className="edit-save-btn" onClick={handleSavePlanetEdit}>저장</button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
