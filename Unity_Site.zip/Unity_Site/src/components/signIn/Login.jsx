// src/components/signIn/Login.jsx
import React, { useState, useEffect } from "react";
import "./Login.css";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

function Login({ isOpen, onClose, navigate, onLoginSuccess }) {
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");

  // 모달이 닫힐 때 입력값 초기화
  useEffect(() => {
    if (!isOpen) {
      setId("");
      setPassword("");
    }
  }, [isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`${API_BASE}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
        body: new URLSearchParams({
          id,
          password,
        }).toString(),
      });

      const data = await response.json();

      if (data.success) {
        // 입력값 초기화
        setId("");
        setPassword("");

        // Main.jsx로 로그인 성공 알림
        if (onLoginSuccess) onLoginSuccess(id);

        onClose();
        if (navigate) navigate("/");
      } else {
        alert(data.message || "아이디 또는 비밀번호가 올바르지 않습니다.");
      }
    } catch (err) {
      console.error("로그인 요청 실패:", err);
      alert("서버 오류가 발생했습니다.");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="login-modal-content">
        {/* 제목 */}
        <h2>Sign In</h2>

        {/* 로그인 폼 */}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="login-id">ID</label>
            <input
              id="login-id"
              type="text"
              value={id}
              onChange={(e) => setId(e.target.value)}
              placeholder="Enter your ID"
            />
          </div>

          <div className="form-group">
            <label htmlFor="login-password">Password</label>
            <input
              id="login-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
            />
          </div>

          <button type="submit" className="login-button">
            Login
          </button>
        </form>

        {/* 회원가입 링크 안내 (원하면 SignUp 이동 버튼으로 나중에 연결) */}
        <div className="signup-link">
          Don't have an account?
          {/* <a onClick={...}>Sign Up</a>  이런 식으로 나중에 연결 가능 */}
        </div>

        {/* 닫기 버튼 (CSS와 className 맞춤) */}
        <button className="close-button" onClick={onClose}>
          ✕
        </button>
      </div>
    </div>
  );
}

export default Login;
