// src/components/Main.jsx
import React, { useState, useCallback, useEffect } from "react";
import "./Main.css";

import Header from "../header/Header";
import Login from "../signIn/Login";
import SignUp from "../signUp/SignUp";
import SpaceBackground from "../background/SpaceBackground";

const CONTEXT_PATH = "/MemorySpace";
// ✅ API 공통 prefix
const API_BASE = `${CONTEXT_PATH}/api`;

const stripContextPath = (pathname) => {
  if (!pathname.startsWith(CONTEXT_PATH)) return pathname || "/";
  let stripped = pathname.slice(CONTEXT_PATH.length);
  if (stripped === "" || stripped === "/" || stripped === "/index.html") return "/";
  return stripped.startsWith("/") ? stripped : `/${stripped}`;
};

const Main = () => {
  // ⭐ 로그인 상태 관리
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [nickname, setNickname] = useState("");

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const initialPath = stripContextPath(window.location.pathname || "/");
  const [currentPage, setCurrentPage] = useState(initialPath);

  const handleOpenLogin = () => setIsLoginModalOpen(true);
  const handleCloseLogin = () => setIsLoginModalOpen(false);

  // ✅ 로그인 성공시 호출되는 함수 (Login.jsx → Main.jsx)
  const handleLoginSuccess = (userIdOrNickname) => {
    setIsLoggedIn(true);
    setNickname(userIdOrNickname || "");
  };

  // ✅ 로그아웃 처리 함수 (Header → Main)
  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE}/logout`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        // same-origin 이라 쿠키 자동 전송, credentials 굳이 안 줘도 됨
      });
    } catch (e) {
      console.error("로그아웃 요청 실패:", e);
    } finally {
      // 서버 세션이 날아가든 말든, 프론트 상태는 일단 정리
      setIsLoggedIn(false);
      setNickname("");
      setIsLoginModalOpen(false);
      // 필요하면 메인으로 보내기
      const logicalPath = "/";
      const fullPath = `${CONTEXT_PATH}/index.html`;
      window.history.pushState({}, "", fullPath);
      setCurrentPage(logicalPath);
    }
  };

  // ✅ 새로고침 했을 때 서버 세션 기준으로 로그인 상태 복원
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await fetch(`${API_BASE}/auth/me`, {
          method: "GET",
          headers: {
            "Accept": "application/json",
          },
        });

        if (!res.ok) {
          // 401 같은 경우 → 비로그인 상태
          return;
        }

        const data = await res.json();
        if (data.loggedIn) {
          setIsLoggedIn(true);
          // 서버가 nickname 있으면 nickname, 없으면 userId 사용
          setNickname(data.nickname || data.userId || "");
        }
      } catch (e) {
        console.error("로그인 상태 확인 실패:", e);
      }
    };

    checkAuth();
  }, []);

  const navigate = useCallback((path, options = {}) => {
    const logicalPath = path.startsWith("/") ? path : `/${path}`;
    const fullPath =
      logicalPath === "/"
        ? `${CONTEXT_PATH}/index.html`
        : `${CONTEXT_PATH}${logicalPath}`;

    window.history.pushState({}, "", fullPath);
    setCurrentPage(logicalPath);

    if (options.openLogin) setIsLoginModalOpen(true);
    else setIsLoginModalOpen(false);
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      const pathname = stripContextPath(window.location.pathname);
      setCurrentPage(pathname);
      setIsLoginModalOpen(false);
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const renderContent = () => {
    switch (currentPage) {
      case "/signup":
        return <SignUp navigate={navigate} />;
      case "/":
      default:
        return (
          <main className="main-wrapper">
            <SpaceBackground />
          </main>
        );
    }
  };

  return (
    <div className="app-root">
      <Header
        onLoginClick={handleOpenLogin}
        navigate={navigate}
        isLoggedIn={isLoggedIn}
        nickname={nickname}
        onLogout={handleLogout}        // ✅ 로그아웃 콜백 전달
      />

      {renderContent()}

      <Login
        isOpen={isLoginModalOpen}
        onClose={handleCloseLogin}
        navigate={navigate}
        onLoginSuccess={handleLoginSuccess} // ⭐ 로그인 성공 callback 전달
      />
    </div>
  );
};

export default Main;
