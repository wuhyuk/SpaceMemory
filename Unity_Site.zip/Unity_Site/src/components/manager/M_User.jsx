// manager/M_User.jsx
import React, { useEffect, useMemo, useState } from "react";
import "./M_User.css";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

function M_User({ reloadKey }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // 검색 / 필터 / 정렬 상태
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [regionFilter, setRegionFilter] = useState("ALL");
  const [sortKey, setSortKey] = useState("ID_DESC");

  // 페이지네이션 상태
  const [pageSize, setPageSize] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  // 상세 + 상태 변경 모달용
  const [selectedUser, setSelectedUser] = useState(null);
  const [statusForm, setStatusForm] = useState({
    status: "",
    penaltyDays: "",
  });
  const [updatingUserId, setUpdatingUserId] = useState(null);

  // 최초 로딩 시 유저 목록 가져오기
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const res = await fetch(`${API_BASE}/admin/users`);
        const data = await res.json();
        setUsers(data.users || []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [reloadKey]);   // 🔥 추가

  // 검색/필터/정렬/페이지당 개수 바뀔 때마다 페이지를 1페이지로 리셋
  useEffect(() => {
    setCurrentPage(1);
  }, [search, roleFilter, regionFilter, sortKey, pageSize]);

  // 지역 선택 옵션 (users 기준으로 자동 생성)
  const regionOptions = useMemo(() => {
    const set = new Set();
    users.forEach((u) => {
      const region = (u.liveIn || "").trim();
      if (region) set.add(region);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, "ko"));
  }, [users]);

  // 상태 텍스트 생성 (예: 정상 / 정지(남은 2일) / 영구 정지)
  const getStatusLabel = (user) => {
    const status = user.status || "ACTIVE";
    const penaltyEndAt = user.penaltyEndAt;

    if (status === "SUSPENDED") {
      if (!penaltyEndAt) return "정지 (기간 정보 없음)";

      const now = Date.now();
      const end = new Date(penaltyEndAt).getTime();
      const diffMs = end - now;

      if (diffMs <= 0) {
        return "정지 (기간 만료)";
      }

      const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
      return `정지 (남은 ${diffDays}일)`;
    }

    if (status === "BANNED") {
      return "영구 정지";
    }

    // ACTIVE or 기타
    return "정상";
  };

  // 필터/검색/정렬 적용된 유저 목록
  const filteredUsers = useMemo(() => {
    let list = [...users];

    // 검색 (닉네임 / 아이디 / 이메일)
    if (search.trim() !== "") {
      const q = search.trim().toLowerCase();
      list = list.filter((u) => {
        const nickname = (u.nickname || "").toLowerCase();
        const username = (u.username || "").toLowerCase();
        const email = (u.email || "").toLowerCase();
        return (
          nickname.includes(q) || username.includes(q) || email.includes(q)
        );
      });
    }

    // 권한 필터
    if (roleFilter !== "ALL") {
      list = list.filter((u) => (u.role || "") === roleFilter);
    }

    // 지역 필터
    if (regionFilter !== "ALL") {
      list = list.filter((u) => (u.liveIn || "") === regionFilter);
    }

    // 정렬
    list.sort((a, b) => {
      switch (sortKey) {
        case "NAME_ASC": {
          const an = (a.nickname || a.username || "").toLowerCase();
          const bn = (b.nickname || b.username || "").toLowerCase();
          if (an < bn) return -1;
          if (an > bn) return 1;
          return 0;
        }
        case "POST_DESC":
          return (b.postCount || 0) - (a.postCount || 0);
        case "REPORT_DESC":
          // 신고 누적수 기준 내림차순
          return (b.reportCount || 0) - (a.reportCount || 0);
        case "ID_ASC":
          return (a.id || 0) - (b.id || 0);
        case "ID_DESC":
        default:
          return (b.id || 0) - (a.id || 0);
      }
    });

    return list;
  }, [users, search, roleFilter, regionFilter, sortKey]);

  // 페이지네이션 계산
  const totalPages = Math.max(
    1,
    Math.ceil((filteredUsers.length || 1) / pageSize)
  );
  const safePage = Math.min(currentPage, totalPages);
  const startIndex = (safePage - 1) * pageSize;
  const pagedUsers = filteredUsers.slice(startIndex, startIndex + pageSize);

  const handlePrevPage = () => {
    setCurrentPage((prev) => Math.max(1, prev - 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prev) => Math.min(totalPages, prev + 1));
  };

  // 상세 모달 열기
  const handleOpenDetail = (user) => {
    setSelectedUser(user);
    setStatusForm({
      status: user.status || "ACTIVE",
      penaltyDays: "",
    });
  };

  // 상세 모달 닫기
  const handleCloseDetail = () => {
    setSelectedUser(null);
    setStatusForm({ status: "", penaltyDays: "" });
  };

  // 상태 변경 폼 변경
  const handleStatusFormChange = (field, value) => {
    setStatusForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // 상태 변경 요청
  const handleUpdateStatus = async () => {
    if (!selectedUser) return;

    const newStatus = statusForm.status || "ACTIVE";
    let penaltyDaysParam = "";

    if (newStatus === "SUSPENDED") {
      const d = parseInt(statusForm.penaltyDays, 10);
      if (Number.isNaN(d) || d <= 0) {
        alert("정지 기간(일)을 1 이상 숫자로 입력해주세요.");
        return;
      }
      penaltyDaysParam = String(d);
    }

    console.log("[DEBUG] handleUpdateStatus start", {
      selectedUser,
      statusForm,
      newStatus,
      penaltyDaysParam,
    });

    setUpdatingUserId(selectedUser.id);

    try {
      const params = new URLSearchParams();
      params.append("userId", String(selectedUser.id));
      params.append("status", newStatus);
      if (penaltyDaysParam) {
        params.append("penaltyDays", penaltyDaysParam);
      }

      console.log("[DEBUG] request URL", `${API_BASE}/admin/users/status`);
      console.log("[DEBUG] request body", params.toString());

      const res = await fetch(`${API_BASE}/admin/users/status`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
        body: params.toString(),
      });


      console.log("[DEBUG] response status", res.status);

      const rawText = await res.text();
      console.log("[DEBUG] raw response text", rawText);

      if (!res.ok) {
        throw new Error("서버 응답 오류, status=" + res.status);
      }

      let data;
      try {
        data = JSON.parse(rawText);
      } catch (e) {
        console.error("[DEBUG] JSON parse error", e);
        throw new Error("JSON 파싱 실패: " + rawText);
      }

      console.log("[DEBUG] parsed response JSON", data);

      if (!data.success) {
        throw new Error(data.message || "상태 변경 실패");
      }

      const updatedUser = data.user || {
        id: selectedUser.id,
        status: newStatus,
        penaltyEndAt: data.penaltyEndAt || null,
      };

      setUsers((prev) =>
        prev.map((u) => (u.id === updatedUser.id ? { ...u, ...updatedUser } : u))
      );
      setSelectedUser((prev) =>
        prev && prev.id === updatedUser.id ? { ...prev, ...updatedUser } : prev
      );

      alert("사용자 상태가 변경되었습니다.");
    } catch (e) {
      console.error("사용자 상태 변경 실패:", e);
      alert("사용자 상태 변경 중 오류가 발생했습니다.\n" + e.message);
    } finally {
      setUpdatingUserId(null);
    }
  };


  return (
    <div className="m-user-container">
      <h2>회원 목록</h2>

      {/* 상단 컨트롤 바 */}
      <div className="m-user-controls">
        <input
          type="text"
          className="m-user-search-input"
          placeholder="닉네임 / ID / 이메일 검색"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {/* 권한 필터 */}
        <select
          className="m-user-select"
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
        >
          <option value="ALL">모든 권한</option>
          <option value="USER">USER</option>
          <option value="ADMIN">ADMIN</option>
        </select>

        {/* 지역 필터 */}
        <select
          className="m-user-select"
          value={regionFilter}
          onChange={(e) => setRegionFilter(e.target.value)}
        >
          <option value="ALL">모든 지역</option>
          {regionOptions.map((region) => (
            <option key={region} value={region}>
              {region}
            </option>
          ))}
        </select>

        {/* 정렬 */}
        <select
          className="m-user-select"
          value={sortKey}
          onChange={(e) => setSortKey(e.target.value)}
        >
          <option value="ID_DESC">최근 가입순 (ID ↓)</option>
          <option value="ID_ASC">오래된 가입순 (ID ↑)</option>
          <option value="NAME_ASC">닉네임/ID 가나다 순</option>
          <option value="POST_DESC">게시물 수 많은 순</option>
          <option value="REPORT_DESC">신고 누적 많은 순</option>
        </select>

        {/* 페이지당 개수 */}
        <select
          className="m-user-select"
          value={pageSize}
          onChange={(e) => setPageSize(Number(e.target.value))}
        >
          <option value={5}>5명씩</option>
          <option value={10}>10명씩</option>
          <option value={20}>20명씩</option>
          <option value={50}>50명씩</option>
        </select>
      </div>

      {/* 로딩/에러 표시 */}
      {loading && <div className="m-user-message">로딩 중...</div>}
      {error && <div className="m-user-message m-user-error">{error}</div>}

      {/* 테이블 */}
      <table className="m-user-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>닉네임</th>
            <th>아이디</th>
            <th>이메일</th>
            <th>지역</th>
            <th>권한</th>
            <th>상태</th>
            <th>게시물 수</th>
            <th>신고 누적수</th>
            <th>관리</th>
          </tr>
        </thead>
        <tbody>
          {pagedUsers.length === 0 ? (
            <tr>
              <td colSpan={10} style={{ textAlign: "center" }}>
                조건에 맞는 회원이 없습니다.
              </td>
            </tr>
          ) : (
            pagedUsers.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.nickname}</td>
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td>{user.liveIn}</td>
                <td>{user.role}</td>
                <td className={
                  user.status === "ACTIVE"
                    ? "m-user-status-active"
                    : user.status === "SUSPENDED"
                    ? "m-user-status-suspended"
                    : "m-user-status-banned"
                }>
                  {getStatusLabel(user)}
                </td>
                <td>{user.postCount}</td>
                <td>{user.reportCount ?? 0}</td>
                <td>
                  <button
                    className="m-user-detail-btn"
                    onClick={() => handleOpenDetail(user)}
                  >
                    상세
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {/* 페이지네이션 */}
      <div className="m-user-pagination">
        <button
          className="m-user-page-btn"
          onClick={handlePrevPage}
          disabled={safePage <= 1}
        >
          ‹
        </button>
        <span className="m-user-page-info">
          Page {safePage} / {totalPages} (총 {filteredUsers.length}명)
        </span>
        <button
          className="m-user-page-btn"
          onClick={handleNextPage}
          disabled={safePage >= totalPages}
        >
          ›
        </button>
      </div>

      {/* 상세 + 상태 변경 모달 */}
      {selectedUser && (
        <div className="m-user-modal-overlay" onClick={handleCloseDetail}>
          <div
            className="m-user-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <h3>회원 상세정보</h3>
            <div className="m-user-modal-content">
              <p>
                <strong>ID:</strong> {selectedUser.id}
              </p>
              <p>
                <strong>아이디(username):</strong> {selectedUser.username}
              </p>
              <p>
                <strong>닉네임:</strong> {selectedUser.nickname}
              </p>
              <p>
                <strong>이메일:</strong> {selectedUser.email}
              </p>
              <p>
                <strong>지역:</strong> {selectedUser.liveIn || "-"}
              </p>
              <p>
                <strong>권한:</strong> {selectedUser.role}
              </p>
              <p>
                <strong>현재 상태:</strong> {getStatusLabel(selectedUser)}
              </p>
              <p>
                <strong>게시물 수:</strong> {selectedUser.postCount}
              </p>
              <p>
                <strong>신고 누적수:</strong>{" "}
                {selectedUser.reportCount ?? 0}
              </p>
              <p>
                <strong>마지막 로그인:</strong>{" "}
                {selectedUser.lastLoginTime || "-"}
              </p>

              <hr style={{ margin: "12px 0", borderColor: "#3a4552" }} />

              {/* 상태 변경 폼 */}
              <p>
                <strong>새 상태 설정</strong>
              </p>
              <p>
                <select
                  className="m-user-select"
                  value={statusForm.status || "ACTIVE"}
                  onChange={(e) =>
                    handleStatusFormChange("status", e.target.value)
                  }
                >
                  <option value="ACTIVE">정상 (ACTIVE)</option>
                  <option value="SUSPENDED">정지 (SUSPENDED)</option>
                  <option value="BANNED">영구 정지 (BANNED)</option>
                </select>
              </p>

              {statusForm.status === "SUSPENDED" && (
                <p>
                  <input
                    type="number"
                    min={1}
                    className="m-user-search-input"
                    placeholder="정지 기간(일)을 입력하세요"
                    value={statusForm.penaltyDays}
                    onChange={(e) =>
                      handleStatusFormChange("penaltyDays", e.target.value)
                    }
                  />
                </p>
              )}
            </div>

            <div className="m-user-modal-actions">
              <button
                className="m-user-status-btn"
                onClick={handleUpdateStatus}
                disabled={updatingUserId === selectedUser.id}
              >
                {updatingUserId === selectedUser.id ? "변경 중..." : "상태 변경"}
              </button>
                        
              <button
                className="m-user-detail-btn"
                onClick={handleCloseDetail}
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default M_User;
