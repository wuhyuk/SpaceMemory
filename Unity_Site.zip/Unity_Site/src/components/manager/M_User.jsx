// manager/M_User.jsx
import React, { useEffect, useMemo, useState } from "react";
import "./M_User.css";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

function M_User() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // 검색 / 필터 / 정렬 상태
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [regionFilter, setRegionFilter] = useState("ALL");
  const [sortKey, setSortKey] = useState("ID_DESC");

  // 페이지네이션 상태
  const [pageSize, setPageSize] = useState(10); // 페이지당 표시할 회원 수
  const [currentPage, setCurrentPage] = useState(1);

  // 상세보기용
  const [selectedUser, setSelectedUser] = useState(null);

  // 최초 로딩 시 유저 목록 가져오기
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      setError("");

      try {
        const res = await fetch(`${API_BASE}/admin/users`, {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });

        if (!res.ok) {
          throw new Error("서버 응답 오류");
        }

        const data = await res.json();
        setUsers(data.users || []);
      } catch (e) {
        console.error("관리자 유저 목록 조회 실패:", e);
        setError("회원 목록을 불러오는 중 오류가 발생했습니다.");
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // 검색/필터 바뀔 때마다 페이지를 1페이지로 리셋
  useEffect(() => {
    setCurrentPage(1);
  }, [search, roleFilter, regionFilter, sortKey, pageSize]);

  // DB에서 넘어온 지역 목록 기반으로 필터 옵션 생성
  const regionOptions = useMemo(() => {
    const set = new Set();
    users.forEach((u) => {
      if (u.liveIn && u.liveIn.trim() !== "") {
        set.add(u.liveIn.trim());
      }
    });
    return Array.from(set);
  }, [users]);

  // 상태 텍스트 생성 (예: 정상 / 정지(남은 2일) / 영구 정지)
  const getStatusLabel = (user) => {
    const status = user.status || "ACTIVE";
    const penaltyEndAt = user.penaltyEndAt;

    if (status === "SUSPENDED") {
      if (!penaltyEndAt) return "정지 (기간 정보 없음)";

      const now = Date.now();
      const end = new Date(penaltyEndAt).getTime();
      const diffMs = end - now;

      if (diffMs <= 0) {
        return "정지 (기간 만료)";
      }

      const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
      return `정지 (남은 ${diffDays}일)`;
    }

    if (status === "BANNED") {
      return "영구 정지";
    }

    // ACTIVE or 기타
    return "정상";
  };

  // 검색 + 필터 + 정렬 적용된 리스트
  const filteredUsers = useMemo(() => {
    let list = [...users];

    // 검색 (닉네임 / 아이디 / 이메일)
    if (search.trim() !== "") {
      const q = search.trim().toLowerCase();
      list = list.filter((u) => {
        const nickname = (u.nickname || "").toLowerCase();
        const username = (u.username || "").toLowerCase();
        const email = (u.email || "").toLowerCase();
        return (
          nickname.includes(q) || username.includes(q) || email.includes(q)
        );
      });
    }

    // 권한 필터
    if (roleFilter !== "ALL") {
      list = list.filter((u) => (u.role || "") === roleFilter);
    }

    // 지역 필터
    if (regionFilter !== "ALL") {
      list = list.filter((u) => (u.liveIn || "") === regionFilter);
    }

    // 정렬
    list.sort((a, b) => {
      switch (sortKey) {
        case "NAME_ASC": {
          const an = (a.nickname || a.username || "").toLowerCase();
          const bn = (b.nickname || b.username || "").toLowerCase();
          if (an < bn) return -1;
          if (an > bn) return 1;
          return 0;
        }
        case "POST_DESC":
          return (b.postCount || 0) - (a.postCount || 0);
        case "REPORT_DESC":
          // 🔥 신고 누적수 기준 내림차순
          return (b.reportCount || 0) - (a.reportCount || 0);
        case "ID_ASC":
          return (a.id || 0) - (b.id || 0);
        case "ID_DESC":
        default:
          return (b.id || 0) - (a.id || 0);
      }
    });

    return list;
  }, [users, search, roleFilter, regionFilter, sortKey]);

  // 페이지네이션 계산
  const totalPages = Math.max(
    1,
    Math.ceil(filteredUsers.length / pageSize || 1)
  );
  const safePage = Math.min(currentPage, totalPages);
  const startIndex = (safePage - 1) * pageSize;
  const pagedUsers = filteredUsers.slice(startIndex, startIndex + pageSize);

  const handleOpenDetail = (user) => {
    setSelectedUser(user);
  };

  const handleCloseDetail = () => {
    setSelectedUser(null);
  };

  const handlePrevPage = () => {
    setCurrentPage((prev) => Math.max(1, prev - 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prev) => Math.min(totalPages, prev + 1));
  };

  return (
    <div className="m-user-container">
      <h2>회원 목록</h2>

      {/* 컨트롤 영역: 검색 / 필터 / 정렬 / 페이지당 개수 */}
      <div className="m-user-controls">
        {/* 검색 */}
        <input
          type="text"
          className="m-user-search-input"
          placeholder="닉네임 / ID / 이메일 검색"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {/* 권한 필터 */}
        <select
          className="m-user-select"
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
        >
          <option value="ALL">모든 권한</option>
          <option value="USER">USER</option>
          <option value="ADMIN">ADMIN</option>
        </select>

        {/* 지역 필터 */}
        <select
          className="m-user-select"
          value={regionFilter}
          onChange={(e) => setRegionFilter(e.target.value)}
        >
          <option value="ALL">모든 지역</option>
          {regionOptions.map((region) => (
            <option key={region} value={region}>
              {region}
            </option>
          ))}
        </select>

        {/* 정렬 */}
        <select
          className="m-user-select"
          value={sortKey}
          onChange={(e) => setSortKey(e.target.value)}
        >
          <option value="ID_DESC">최근 가입순 (ID ↓)</option>
          <option value="ID_ASC">오래된 가입순 (ID ↑)</option>
          <option value="NAME_ASC">닉네임/ID 가나다 순</option>
          <option value="POST_DESC">게시물 수 많은 순</option>
          <option value="REPORT_DESC">신고 누적 많은 순</option>
        </select>

        {/* 페이지당 개수 */}
        <select
          className="m-user-select"
          value={pageSize}
          onChange={(e) => setPageSize(Number(e.target.value))}
        >
          <option value={5}>5명씩</option>
          <option value={10}>10명씩</option>
          <option value={20}>20명씩</option>
          <option value={50}>50명씩</option>
        </select>
      </div>

      {/* 로딩/에러 표시 */}
      {loading && <div className="m-user-message">로딩 중...</div>}
      {error && <div className="m-user-message m-user-error">{error}</div>}

      {/* 테이블 */}
      <table className="m-user-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>닉네임</th>
            <th>아이디</th>
            <th>이메일</th>
            <th>지역</th>
            <th>권한</th>
            <th>상태</th>
            <th>게시물 수</th>
            <th>신고 누적수</th>
            <th>관리</th>
          </tr>
        </thead>
        <tbody>
          {pagedUsers.length === 0 ? (
            <tr>
              <td colSpan={10} style={{ textAlign: "center" }}>
                조건에 맞는 회원이 없습니다.
              </td>
            </tr>
          ) : (
            pagedUsers.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.nickname}</td>
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td>{user.liveIn}</td>
                <td>{user.role}</td>
                <td>{getStatusLabel(user)}</td>
                <td>{user.postCount}</td>
                <td>{user.reportCount ?? 0}</td>
                <td>
                  <button
                    className="m-user-detail-btn"
                    onClick={() => handleOpenDetail(user)}
                  >
                    상세
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {/* 페이지네이션 바 */}
      <div className="m-user-pagination">
        <button
          className="m-user-page-btn"
          onClick={handlePrevPage}
          disabled={safePage <= 1}
        >
          ‹
        </button>
        <span className="m-user-page-info">
          Page {safePage} / {totalPages} (총 {filteredUsers.length}명)
        </span>
        <button
          className="m-user-page-btn"
          onClick={handleNextPage}
          disabled={safePage >= totalPages}
        >
          ›
        </button>
      </div>

      {/* 상세보기 모달 */}
      {selectedUser && (
        <div className="m-user-modal-overlay" onClick={handleCloseDetail}>
          <div
            className="m-user-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <h3>회원 상세정보</h3>
            <div className="m-user-modal-content">
              <p>
                <strong>ID:</strong> {selectedUser.id}
              </p>
              <p>
                <strong>아이디(username):</strong> {selectedUser.username}
              </p>
              <p>
                <strong>닉네임:</strong> {selectedUser.nickname}
              </p>
              <p>
                <strong>이메일:</strong> {selectedUser.email}
              </p>
              <p>
                <strong>지역:</strong> {selectedUser.liveIn || "-"}
              </p>
              <p>
                <strong>권한:</strong> {selectedUser.role}
              </p>
              <p>
                <strong>상태:</strong> {getStatusLabel(selectedUser)}
              </p>
              <p>
                <strong>게시물 수:</strong> {selectedUser.postCount}
              </p>
              <p>
                <strong>신고 누적수:</strong> {selectedUser.reportCount ?? 0}
              </p>
              <p>
                <strong>정지 종료 시각:</strong>{" "}
                {selectedUser.penaltyEndAt && selectedUser.penaltyEndAt !== ""
                  ? selectedUser.penaltyEndAt
                  : "-"}
              </p>
            </div>

            <div className="m-user-modal-actions">
              <button onClick={handleCloseDetail}>닫기</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default M_User;
