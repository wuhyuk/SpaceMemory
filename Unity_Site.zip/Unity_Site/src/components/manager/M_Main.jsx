// manager/M_Main.jsx
import React, { useEffect, useState } from "react";
import "./M_Main.css";
import M_Header from "./M_Header";
import M_User from "./M_User";
import M_Decl from "./M_Decl";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

function M_Main({ nickname, onLogout }) {
  const [stats, setStats] = useState({
    totalUsers: 0,
    storage: { used: 0, total: 0 },
    regions: {},
  });

  const [userReloadKey, setUserReloadKey] = useState(0);

  const triggerUserReload = () => {
    setUserReloadKey((prev) => prev + 1);
  };

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch(`${API_BASE}/admin/stats`);
        if (!res.ok) throw new Error("stats error");
        const data = await res.json();
        setStats(data);
      } catch (e) {
        console.error("관리자 통계 조회 실패:", e);
      }
    };
    fetchStats();
  }, []);

  // GB 단위 변환
  const toGB = (bytes) => (bytes / (1024 * 1024 * 1024)).toFixed(2);

  return (
    <div className="m-container">
      <M_Header nickname={nickname} onLogout={onLogout} />

      <div className="m-content-wrapper">
        
        {/* 관리자 대시보드 */}
        <div className="m-dashboard">

          <div className="m-box">
            <h2>전체 회원 수</h2>
            <p>{stats.totalUsers} 명</p>
          </div>

          <div className="m-box">
            <h2>저장 용량</h2>
            <p>
              사용됨: {toGB(stats.storage.used)}GB / 전체 {toGB(stats.storage.total)}GB
            </p>
          </div>

          <div className="m-box">
            <h2>지역 분포</h2>
            <ul>
              {Object.keys(stats.regions).map((region) => (
                <li key={region}>
                  {region}: {stats.regions[region]} 명
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* 회원 목록 */}
         <M_User reloadKey={userReloadKey} />

        {/* 신고된 게시물 */}
        <M_Decl onUserDataChange={triggerUserReload} />
      </div>
    </div>
  );
}

export default M_Main;
