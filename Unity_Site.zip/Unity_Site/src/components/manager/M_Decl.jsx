// manager/M_Decl.jsx
import React, { useEffect, useMemo, useState } from "react";
import "./M_Decl.css";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

function M_Decl() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // 필터/검색/정렬 상태
  const [statusFilter, setStatusFilter] = useState("ALL"); // ALL | NEW | PROCESSED
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState("LATEST"); // LATEST | OLDEST | PLANET

  // 페이지네이션 상태
  const [pageSize, setPageSize] = useState(10); // 한 페이지에 몇 개씩 볼지
  const [currentPage, setCurrentPage] = useState(1);

  // 처리 중인 신고 ID
  const [processingId, setProcessingId] = useState(null);

  // 모달 상태 (처리 대상 신고)
  const [actionTarget, setActionTarget] = useState(null);

  // 신고 목록 불러오기
  const fetchReports = async () => {
    setLoading(true);
    setError("");

    try {
      const res = await fetch(`${API_BASE}/admin/reports`, {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      });

      if (!res.ok) {
        throw new Error("서버 응답 오류");
      }

      const data = await res.json();
      setReports(data.reports || []);
    } catch (e) {
      console.error("신고 목록 조회 실패:", e);
      setError("신고 목록을 불러오는 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  // 필터/검색/정렬 옵션 바뀔 때마다 페이지를 1로 리셋
  useEffect(() => {
    setCurrentPage(1);
  }, [statusFilter, search, sortKey, pageSize]);

  // 사유 기반 카테고리 태그
  const getCategory = (reason = "") => {
    const r = reason.toLowerCase();
    if (r.includes("욕설") || r.includes("비방") || r.includes("모욕")) {
      return { key: "abuse", label: "욕설/비방" };
    }
    if (
      r.includes("이미지") ||
      r.includes("사진") ||
      r.includes("영상") ||
      r.includes("동영상")
    ) {
      return { key: "image", label: "부적절한 이미지/영상" };
    }
    if (r.includes("스팸") || r.includes("광고")) {
      return { key: "spam", label: "스팸/광고" };
    }
    return { key: "etc", label: "기타" };
  };

  const getStatusLabel = (status) => {
    if (status === "processed") return "처리 완료";
    if (status === "new") return "신규";
    return status || "-";
  };

  // 필터 + 검색 + 정렬 적용
  const filteredReports = useMemo(() => {
    let list = [...reports];

    // 상태 필터
    if (statusFilter === "NEW") {
      list = list.filter((r) => r.status === "new");
    } else if (statusFilter === "PROCESSED") {
      list = list.filter((r) => r.status === "processed");
    }

    // 검색 (행성 이름 / 신고자 / 사유)
    if (search.trim() !== "") {
      const q = search.trim().toLowerCase();
      list = list.filter((r) => {
        const planetName = (r.planetName || "").toLowerCase();
        const reporter = (r.reporterNickname || "").toLowerCase();
        const reason = (r.reason || "").toLowerCase();
        return (
          planetName.includes(q) ||
          reporter.includes(q) ||
          reason.includes(q)
        );
      });
    }

    // 정렬
    list.sort((a, b) => {
      switch (sortKey) {
        case "OLDEST":
          return (a.id || 0) - (b.id || 0);
        case "PLANET":
          return (a.planetId || 0) - (b.planetId || 0);
        case "LATEST":
        default:
          return (b.id || 0) - (a.id || 0);
      }
    });

    return list;
  }, [reports, statusFilter, search, sortKey]);

  // 페이지네이션 계산
  const totalPages = Math.max(
    1,
    Math.ceil((filteredReports.length || 1) / pageSize)
  );
  const safePage = Math.min(currentPage, totalPages);
  const startIndex = (safePage - 1) * pageSize;
  const pagedReports = filteredReports.slice(
    startIndex,
    startIndex + pageSize
  );

  const handlePrevPage = () => {
    setCurrentPage((prev) => Math.max(1, prev - 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prev) => Math.min(totalPages, prev + 1));
  };

  // 행성 보기
  const handleViewPlanet = (planetId) => {
    if (!planetId) return;
    // 라우팅 규칙에 맞게 수정 가능
    window.open(`${CONTEXT_PATH}/planet/${planetId}`, "_blank");
  };

  // 모달 열기/닫기
  const openActionModal = (report) => {
    setActionTarget(report);
  };

  const closeActionModal = () => {
    setActionTarget(null);
  };

  // 신고만 처리
  const resolveOnly = async (reportId) => {
    try {
      setProcessingId(reportId);

      const res = await fetch(`${API_BASE}/admin/reports/resolve`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
        body: new URLSearchParams({ id: String(reportId) }).toString(),
      });

      if (!res.ok) {
        throw new Error("서버 응답 오류");
      }

      // 상태만 processed로 변경 (카드는 유지)
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId ? { ...r, status: "processed" } : r
        )
      );
      closeActionModal();
    } catch (e) {
      console.error("신고 처리 실패:", e);
      alert("신고 처리 중 오류가 발생했습니다.");
    } finally {
      setProcessingId(null);
    }
  };

  // 게시물 삭제 + 처리 (카드 삭제 X, 상태/표시만 변경)
  const deleteAndResolve = async (reportId, planetId) => {
    try {
      setProcessingId(reportId);

      const res = await fetch(`${API_BASE}/admin/reports/delete-planet`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
        body: new URLSearchParams({
          id: String(reportId),
          planetId: String(planetId),
        }).toString(),
      });

      if (!res.ok) {
        throw new Error("서버 응답 오류");
      }

      // 🔥 더 이상 목록에서 제거하지 않음
      // 행성은 삭제 + 신고는 처리된 상태로 표시
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId
            ? { ...r, status: "processed", planetDeleted: true }
            : r
        )
      );
      closeActionModal();
    } catch (e) {
      console.error("게시물 삭제 실패:", e);
      alert("게시물 삭제 중 오류가 발생했습니다.");
    } finally {
      setProcessingId(null);
    }
  };

  // 모달에서 실제 액션 수행
  const handleActionFromModal = (type) => {
    if (!actionTarget) return;

    if (type === "RESOLVE") {
      resolveOnly(actionTarget.id);
    } else if (type === "DELETE_AND_RESOLVE") {
      const ok = window.confirm(
        "정말로 이 게시물을 삭제하시겠습니까?\n삭제 시 해당 행성은 삭제 처리되고, 신고는 처리 완료 상태로 표시됩니다."
      );
      if (!ok) return;
      deleteAndResolve(actionTarget.id, actionTarget.planetId);
    }
  };

  return (
    <div className="m-decl-container">
      <h2>신고된 게시물 관리</h2>

      {/* 컨트롤 바 */}
      <div className="m-user-controls m-decl-controls">
        {/* 검색 */}
        <input
          type="text"
          className="m-user-search-input"
          placeholder="행성 이름 / 신고자 / 사유 검색"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {/* 상태 필터 */}
        <select
          className="m-user-select"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="ALL">전체 상태</option>
          <option value="NEW">신규만</option>
          <option value="PROCESSED">처리 완료만</option>
        </select>

        {/* 정렬 */}
        <select
          className="m-user-select"
          value={sortKey}
          onChange={(e) => setSortKey(e.target.value)}
        >
          <option value="LATEST">최신 신고순</option>
          <option value="OLDEST">오래된 신고순</option>
          <option value="PLANET">행성 번호순</option>
        </select>

        {/* 페이지당 개수 */}
        <select
          className="m-user-select"
          value={pageSize}
          onChange={(e) => setPageSize(Number(e.target.value))}
        >
          <option value={5}>5개씩</option>
          <option value={10}>10개씩</option>
          <option value={20}>20개씩</option>
          <option value={50}>50개씩</option>
        </select>
      </div>

      {/* 로딩/에러 */}
      {loading && <div className="m-decl-message">로딩 중...</div>}
      {error && <div className="m-decl-message m-decl-error">{error}</div>}

      <div className="m-decl-scroll">
        {pagedReports.length === 0 ? (
          <div className="m-decl-empty">표시할 신고가 없습니다.</div>
        ) : (
          pagedReports.map((r) => {
            const category = getCategory(r.reason || "");

            return (
              <div className="m-decl-box" key={r.id}>
                <div className="m-decl-header-row">
                  <h3>
                    {r.planetName || "제목 없는 게시물"}
                    {r.planetDeleted && (
                      <span className="m-decl-deleted-label">
                        {" "}
                        (삭제된 게시물)
                      </span>
                    )}
                  </h3>
                  <span className={`m-decl-tag m-decl-tag-${category.key}`}>
                    {category.label}
                  </span>
                </div>

                {/* 🔹 신고 ID를 명확하게 별도 요소로 표시 */}
                <p>신고 ID: {r.id}</p>
                <p>행성 ID: {r.planetId}</p>
                <p>신고자: {r.reporterNickname || "익명"}</p>
                <p>사유: {r.reason || "-"}</p>
                <p>상태: {getStatusLabel(r.status)}</p>

                <div className="m-decl-actions">
                  <button
                    onClick={() => handleViewPlanet(r.planetId)}
                    className="m-decl-btn m-decl-btn-view"
                  >
                    행성 보기
                  </button>

                  <button
                    onClick={() => openActionModal(r)}
                    className="m-decl-btn m-decl-btn-resolve"
                    disabled={processingId === r.id}
                  >
                    처리하기
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* 페이지네이션 바 */}
      <div className="m-user-pagination m-decl-pagination">
        <button
          className="m-user-page-btn"
          onClick={handlePrevPage}
          disabled={safePage <= 1}
        >
          ‹
        </button>
        <span className="m-user-page-info">
          Page {safePage} / {totalPages} (총 {filteredReports.length}건)
        </span>
        <button
          className="m-user-page-btn"
          onClick={handleNextPage}
          disabled={safePage >= totalPages}
        >
          ›
        </button>
      </div>

      {/* 처리 선택 모달 */}
      {actionTarget && (
        <div className="m-decl-modal-overlay" onClick={closeActionModal}>
          <div
            className="m-decl-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <h3>신고 처리</h3>
            <p>
              <strong>신고 ID:</strong> {actionTarget.id}
            </p>
            <p>
              <strong>행성:</strong>{" "}
              {actionTarget.planetName || `#${actionTarget.planetId}`}
            </p>
            <p>
              <strong>신고자:</strong>{" "}
              {actionTarget.reporterNickname || "익명"}
            </p>
            <p>
              <strong>사유:</strong> {actionTarget.reason || "-"}
            </p>

            <div className="m-decl-modal-buttons">
              <button
                className="m-decl-btn m-decl-btn-resolve"
                onClick={() => handleActionFromModal("RESOLVE")}
                disabled={processingId === actionTarget.id}
              >
                신고만 처리
              </button>
              <button
                className="m-decl-btn m-decl-btn-delete"
                onClick={() => handleActionFromModal("DELETE_AND_RESOLVE")}
                disabled={processingId === actionTarget.id}
              >
                게시물 삭제
              </button>
            </div>

            <div className="m-decl-modal-footer">
              <button onClick={closeActionModal}>닫기</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default M_Decl;
