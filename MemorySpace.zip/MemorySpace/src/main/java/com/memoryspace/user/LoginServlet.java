package com.memoryspace.user;

import com.memoryspace.db.DBConnectionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.format.DateTimeFormatter;

@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        ApiResponse.setJson(resp);
        PrintWriter out = resp.getWriter();

        String id = req.getParameter("id");
        String password = req.getParameter("password");

        UserDAO userDAO = new UserDAO();

        // 1) Credentials check (기존 흐름 유지: 로그인 확인)
        boolean ok = userDAO.checkLogin(id, password);
        if (!ok) {
            // ⚠️ 프론트 response.ok 이슈 때문에 실패도 200으로 내려줌
            ApiResponse.fail(
                    resp, out,
                    HttpServletResponse.SC_OK,
                    "INVALID_CREDENTIALS",
                    ApiMessages.INVALID_CREDENTIALS
            );
            return;
        }

        // 2) 사용자 정보 조회 (기존 흐름 유지)
        UserDTO user = userDAO.getUserByUsername(id);
        if (user == null) {
            ApiResponse.fail(
                    resp, out,
                    HttpServletResponse.SC_OK,
                    "INVALID_CREDENTIALS",
                    ApiMessages.INVALID_CREDENTIALS
            );
            return;
        }

        // 3) status 체크: 정지/차단이면 로그인 자체 차단 + 사유/기간 내려줌
        String status = user.getStatus();

        if ("SUSPENDED".equals(status)) {
            String penaltyEndAtStr = "";
            if (user.getPenaltyEndAt() != null) {
                penaltyEndAtStr = user.getPenaltyEndAt()
                        .toLocalDateTime()
                        .format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            }

            String reason = fetchLatestReportReason(user.getId());
            if (reason == null || reason.trim().isEmpty()) {
                reason = "Policy violation.";
            }

            ApiResponse.fail(
                    resp, out,
                    HttpServletResponse.SC_OK,
                    "SUSPENDED",
                    ApiMessages.ACCOUNT_SUSPENDED,
                    ApiResponse.obj(
                            ApiResponse.kv("penaltyEndAt", penaltyEndAtStr),
                            ApiResponse.kv("reason", reason)
                    )
            );
            return;
        }

        if ("BANNED".equals(status)) {
            String reason = fetchLatestReportReason(user.getId());
            if (reason == null || reason.trim().isEmpty()) {
                reason = "Policy violation.";
            }

            ApiResponse.fail(
                    resp, out,
                    HttpServletResponse.SC_OK,
                    "BANNED",
                    ApiMessages.ACCOUNT_BANNED,
                    ApiResponse.obj(
                            ApiResponse.kv("reason", reason)
                    )
            );
            return;
        }

        // 4) ✅ ACTIVE → login success (기존 세션 키 유지)
        HttpSession session = req.getSession(true);
        session.setAttribute("loginId", user.getUsername());
        session.setAttribute("loginUserId", user.getId());
        session.setAttribute("loginRole", user.getRole());

        // AuthStatusServlet 호환
        session.setAttribute("nickname", user.getNickname());
        session.setAttribute("role", user.getRole());

        // 5) login_log INSERT (기존 목적 유지: 성공시에만 기록)
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO login_log (user_id) VALUES (?)"
             )) {
            ps.setString(1, user.getUsername());
            ps.executeUpdate();
        } catch (Exception e) {
            // 로깅 실패가 로그인 자체를 막지 않도록 유지
            e.printStackTrace();
        }

        // ✅ FIX: 프론트(Main.jsx handleLoginSuccess)가 즉시 nickname/role을 받을 수 있도록 data에 포함
        ApiResponse.ok(
                out,
                ApiResponse.obj(
                        ApiResponse.kv("userId", user.getUsername()),
                        ApiResponse.kv("nickname", user.getNickname()),
                        ApiResponse.kv("role", user.getRole())
                )
        );
    }

    /**
     * reports 테이블에서 해당 유저(reportedUserId)의 "가장 최신" reason을 가져옵니다.
     * 스키마: reports(reportedUserId, reason, status)
     */
    private String fetchLatestReportReason(long reportedUserId) {
        String sql = "SELECT reason FROM reports WHERE reportedUserId = ? ORDER BY id DESC LIMIT 1";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, reportedUserId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("reason");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
