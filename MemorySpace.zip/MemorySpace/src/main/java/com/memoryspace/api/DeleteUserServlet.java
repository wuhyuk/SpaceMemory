package com.memoryspace.api;

import com.memoryspace.user.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/user/delete")
public class DeleteUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        // 1) 로그인 체크
        HttpSession session = req.getSession(false);
        if (session == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // ✅ LoginServlet에서 저장한 "loginId" 사용
        String username = (String) session.getAttribute("loginId");
        if (username == null || username.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // 2) DAO 호출해서 실제로 계정 삭제
        UserDAO dao = new UserDAO();
        boolean success = dao.deleteUser(username);

        if (success) {
            // 계정 삭제 후 세션 무효화
            session.invalidate();
            out.print("SUCCESS|회원 탈퇴가 완료되었습니다.");
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("FAIL|회원 탈퇴에 실패했습니다.");
        }
    }
}
