// src/main/java/com/memoryspace/api/LogoutServlet.java
package com.memoryspace.api;

import com.memoryspace.db.DBConnectionUtil;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/api/logout")
public class LogoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, jakarta.servlet.http.HttpServletResponse resp)
            throws IOException {

        resp.setContentType("application/json; charset=UTF-8");

        HttpSession session = req.getSession(false);

        if (session != null) {
            // 🔹 login_log에 logout_time 업데이트
            Object logIdObj = session.getAttribute("loginLogId");
            if (logIdObj instanceof Long) {
                long logId = (Long) logIdObj;
                updateLogoutTime(logId);
            }

            session.invalidate();
        }

        try (PrintWriter out = resp.getWriter()) {
            out.write("{\"success\": true}");
        }
    }

    private void updateLogoutTime(long logId) {
        String sql = "UPDATE login_log SET logout_time = NOW() WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, logId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
