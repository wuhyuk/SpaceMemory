package com.memoryspace.api;

import com.memoryspace.user.UserDAO;
import com.memoryspace.user.UserDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/user/info")
public class GetUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("text/plain; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        // 1) 세션 체크
        HttpSession session = req.getSession(false);
        if (session == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // ✅ LoginServlet에서 저장한 이름과 동일하게 사용해야 함
        String username = (String) session.getAttribute("loginId");
        if (username == null || username.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // 2) DB에서 사용자 정보 조회
        UserDAO dao = new UserDAO();
        UserDTO user = dao.getUserByUsername(username);

        if (user == null) {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.print("FAIL|사용자를 찾을 수 없습니다.");
        } else {
            // SUCCESS|username|nickname|email|liveIn
            String liveIn = user.getLiveIn() != null ? user.getLiveIn() : "";
            out.print(
                    "SUCCESS|"
                            + user.getUsername()
                            + "|" + user.getNickname()
                            + "|" + user.getEmail()
                            + "|" + liveIn
            );
        }
    }
}
