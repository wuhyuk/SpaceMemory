package com.memoryspace.api;

import com.memoryspace.user.UserDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/user/verify-password")
public class VerifyPasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain; charset=UTF-8");

        PrintWriter out = resp.getWriter();

        // 1) 로그인 여부 체크 (세션 + loginId)
        HttpSession session = req.getSession(false);
        if (session == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // ✅ LoginServlet에서 저장한 이름과 똑같이 사용해야 함
        String loginId = (String) session.getAttribute("loginId");
        if (loginId == null || loginId.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // 2) 비밀번호 파라미터 읽기
        String password = req.getParameter("password");
        if (password == null || password.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("FAIL|비밀번호를 입력해주세요.");
            return;
        }

        // 3) DB에서 현재 비밀번호가 맞는지 확인
        UserDAO dao = new UserDAO();
        // UserDAO에는 checkLogin(String username, String password) 이미 있음
        boolean ok = dao.checkLogin(loginId, password);

        if (ok) {
            System.out.println("✅ 비밀번호 확인 성공!");
            out.print("SUCCESS|비밀번호가 확인되었습니다.");
        } else {
            System.out.println("❌ 비밀번호 확인 실패!");
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|비밀번호가 일치하지 않습니다.");
        }
    }
}
