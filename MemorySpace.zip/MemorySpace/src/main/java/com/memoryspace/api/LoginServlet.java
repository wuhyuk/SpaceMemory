// src/main/java/com/memoryspace/api/LoginServlet.java
package com.memoryspace.api;

import com.memoryspace.user.UserDAO;
import com.memoryspace.db.DBConnectionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {

    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        String id = req.getParameter("id");
        String password = req.getParameter("password");

        boolean success = userDAO.checkLogin(id, password);

        try (PrintWriter out = resp.getWriter()) {
            if (success) {
                // 🔹 1. 세션 생성 + 로그인 사용자 정보 저장
                HttpSession session = req.getSession(true);
                session.setAttribute("loginId", id);

                // 🔹 2. login_log에 기록
                long logId = insertLoginLog(id);
                if (logId > 0) {
                    session.setAttribute("loginLogId", logId);
                }

                // 🔹 3. 프론트로 응답 (나중에 nickname 있으면 같이 내려줘도 됨)
                out.write("{\"success\": true, \"userId\": \"" + escapeJson(id) + "\"}");
            } else {
                out.write("{\"success\": false, \"message\": \"Invalid id or password\"}");
            }
        }
    }

    private long insertLoginLog(String userId) {
        String sql = "INSERT INTO login_log (user_id, login_time) VALUES (?, NOW())";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, userId);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getLong(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // 나중에 로깅으로 교체
        }
        return -1;
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
