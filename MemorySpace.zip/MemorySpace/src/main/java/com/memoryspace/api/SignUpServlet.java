package com.memoryspace.api;

import com.memoryspace.user.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/signup")
public class SignUpServlet extends HttpServlet {

    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        String id = req.getParameter("id");
        String password = req.getParameter("password");
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String region = req.getParameter("region");

        boolean success;
        String message = null;

        if (userDAO.isUserIdExists(id)) {
            success = false;
            message = "This ID is already in use.";
        } else {
            success = userDAO.createUser(id, password, name, email, region);
            if (!success) {
                message = "Failed to sign up. Please try again.";
            }
        }

        try (PrintWriter out = resp.getWriter()) {
            if (success) {
                out.write("{\"success\": true}");
            } else {
                if (message == null) message = "Unknown error";
                // 따옴표 이스케이프
                message = message.replace("\"", "\\\"");
                out.write("{\"success\": false, \"message\": \"" + message + "\"}");
            }
        }
    }
}
