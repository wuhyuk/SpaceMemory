package com.memoryspace.planet;

import com.memoryspace.db.DBConnectionUtil; // ⭐ 추가
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlanetDAO {
    
    // ❌ 기존의 private getConnection() 메소드 제거
    
    /**
     * 특정 별(Star)에 속한 모든 행성(Planet) 목록 조회 (개수 확인용)
     */
    public List<PlanetDTO> getPlanetsByStarId(Long starId) throws SQLException {
        List<PlanetDTO> planets = new ArrayList<>();
        String sql = "SELECT id, starId, name, isDeleted FROM planets WHERE starId = ? AND isDeleted = 0";
        
        // ⭐ DBConnectionUtil.getConnection() 사용
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setLong(1, starId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    PlanetDTO planet = new PlanetDTO();
                    planet.setId(rs.getLong("id"));
                    planet.setStarId(rs.getLong("starId"));
                    planet.setName(rs.getString("name"));
                    planet.setIsDeleted(rs.getInt("isDeleted")); 
                    planets.add(planet);
                }
            }
        } 
        // SQLException은 호출자(GetUserStarsServlet)에게 위임
        return planets;
    }
}