package com.memoryspace.planet;

import com.memoryspace.db.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * planet_media 테이블과 관련된 DB 작업을 담당하는 DAO
 */
public class PlanetMediaDAO {

    /**
     * 지명 정보가 있는 모든 미디어 조회
     * locationName이 있는 데이터만 반환
     */
    public List<PlanetMediaDTO> getAllLocations() {
        List<PlanetMediaDTO> locations = new ArrayList<>();
        
        String sql = "SELECT id, planetId, mediaType, filePath, sizeBytes, " +
                     "locationName, latitude, longitude " +
                     "FROM planet_media " +
                     "WHERE locationName IS NOT NULL AND locationName != ''";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                PlanetMediaDTO dto = new PlanetMediaDTO();
                dto.setId(rs.getLong("id"));
                dto.setPlanetId(rs.getLong("planetId"));
                dto.setMediaType(rs.getString("mediaType"));
                dto.setFilePath(rs.getString("filePath"));
                dto.setSizeBytes(rs.getLong("sizeBytes"));
                dto.setLocationName(rs.getString("locationName"));
                
                // latitude, longitude는 NULL일 수 있음
                Double lat = rs.getDouble("latitude");
                if (!rs.wasNull()) {
                    dto.setLatitude(lat);
                }
                
                Double lng = rs.getDouble("longitude");
                if (!rs.wasNull()) {
                    dto.setLongitude(lng);
                }
                
                locations.add(dto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return locations;
    }

    /**
     * 특정 미디어의 위도/경도 업데이트
     */
    public boolean updateCoordinates(Long id, Double latitude, Double longitude) {
        String sql = "UPDATE planet_media SET latitude = ?, longitude = ? WHERE id = ?";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDouble(1, latitude);
            pstmt.setDouble(2, longitude);
            pstmt.setLong(3, id);

            int rows = pstmt.executeUpdate();
            return rows == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 새로운 미디어 추가 (지명 포함)
     */
    public boolean insertMedia(Long planetId, String mediaType, String filePath, 
                               String mimeType, Long sizeBytes,
                               String locationName, Double latitude, Double longitude) {
                               
        String sql = "INSERT INTO planet_media " +
                     "(planetId, mediaType, filePath, sizeBytes, locationName, latitude, longitude) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, planetId);
            pstmt.setString(2, mediaType);
            pstmt.setString(3, filePath);
            pstmt.setLong(4, sizeBytes); // 인덱스 변경 (5 -> 4)
            pstmt.setString(5, locationName); // 인덱스 변경 (6 -> 5)
            
            if (latitude != null) {
                pstmt.setDouble(6, latitude); // 인덱스 변경 (7 -> 6)
            } else {
                pstmt.setNull(6, java.sql.Types.DOUBLE);
            }
            
            if (longitude != null) {
                pstmt.setDouble(7, longitude); // 인덱스 변경 (8 -> 7)
            } else {
                pstmt.setNull(7, java.sql.Types.DOUBLE);
            }

            int rows = pstmt.executeUpdate();
            return rows == 1;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * ID로 특정 미디어 조회
     */
    public PlanetMediaDTO getMediaById(Long id) {
        String sql = "SELECT id, planetId, mediaType, filePath, sizeBytes, " +
                     "locationName, latitude, longitude " +
                     "FROM planet_media WHERE id = ?";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    PlanetMediaDTO dto = new PlanetMediaDTO();
                    dto.setId(rs.getLong("id"));
                    dto.setPlanetId(rs.getLong("planetId"));
                    dto.setMediaType(rs.getString("mediaType"));
                    dto.setFilePath(rs.getString("filePath"));
                    dto.setSizeBytes(rs.getLong("sizeBytes"));
                    dto.setLocationName(rs.getString("locationName"));
                    
                    Double lat = rs.getDouble("latitude");
                    if (!rs.wasNull()) {
                        dto.setLatitude(lat);
                    }
                    
                    Double lng = rs.getDouble("longitude");
                    if (!rs.wasNull()) {
                        dto.setLongitude(lng);
                    }
                    
                    return dto;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 특정 행성(planet)의 모든 미디어 조회
     */
    public List<PlanetMediaDTO> getMediaByPlanetId(Long planetId) {
        List<PlanetMediaDTO> mediaList = new ArrayList<>();
        
        // ⚠️ SELECT 문에서 mimeType 제거
        String sql = "SELECT id, planetId, mediaType, filePath, sizeBytes, " +
                     "locationName, latitude, longitude " +
                     "FROM planet_media WHERE planetId = ?";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, planetId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    PlanetMediaDTO dto = new PlanetMediaDTO();
                    dto.setId(rs.getLong("id"));
                    dto.setPlanetId(rs.getLong("planetId"));
                    dto.setMediaType(rs.getString("mediaType"));
                    dto.setFilePath(rs.getString("filePath"));
                    dto.setSizeBytes(rs.getLong("sizeBytes"));
                    dto.setLocationName(rs.getString("locationName"));
                    
                    Double lat = rs.getDouble("latitude");
                    if (!rs.wasNull()) {
                        dto.setLatitude(lat);
                    }
                    
                    Double lng = rs.getDouble("longitude");
                    if (!rs.wasNull()) {
                        dto.setLongitude(lng);
                    }
                    
                    mediaList.add(dto);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return mediaList;
    }
}