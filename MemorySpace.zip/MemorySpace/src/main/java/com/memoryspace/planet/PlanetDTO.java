package com.memoryspace.planet; // 패키지 변경

// planets 테이블 구조를 반영
public class PlanetDTO {
    private Long id;
    private Long starId;
    private String name;
    private int isDeleted; // DAO에서 사용하는 isDeleted 필드 추가 및 타입 통일
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Long getStarId() { return starId; }
    public void setStarId(Long starId) { this.starId = starId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }
}