package com.memoryspace.planet; // 기존 패키지에 임시로 넣을 경우

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;


public class NominatimService {

    private static final String NOMINATIM_URL = "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=";
    
    // ⚠️ Nominatim 사용 시 필수: User-Agent 설정
    private static final String USER_AGENT = "MemorySpaceApp/1.0 (contact@yourdomain.com)"; 

    /**
     * 지명(locationName)을 받아 위도(latitude)와 경도(longitude)를 반환합니다.
     * @param locationName 검색할 지명
     * @return Double 배열 (0: latitude, 1: longitude), 검색 실패 시 null 반환
     */
    public Double[] geocode(String locationName) {
        if (locationName == null || locationName.trim().isEmpty()) {
            return null;
        }

        try {
            // URL 인코딩
            String encodedLocation = URLEncoder.encode(locationName, StandardCharsets.UTF_8.toString());
            String fullUrl = NOMINATIM_URL + encodedLocation;

            URL url = new URL(fullUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(5000); // 5초 연결 타임아웃
            conn.setReadTimeout(5000); // 5초 읽기 타임아웃

            int responseCode = conn.getResponseCode();
            
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // 성공적으로 응답을 받음
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                // JSON 파싱
                JsonArray jsonArray = JsonParser.parseString(response.toString()).getAsJsonArray();
                
                if (jsonArray.size() > 0) {
                    JsonObject result = jsonArray.get(0).getAsJsonObject();
                    
                    // 'lat' (위도)와 'lon' (경도)를 추출
                    double lat = result.get("lat").getAsDouble();
                    double lon = result.get("lon").getAsDouble();
                    
                    return new Double[]{lat, lon};
                }
            } else {
                System.err.println("Nominatim API Error: Response Code " + responseCode + " for " + locationName);
            }

        } catch (Exception e) {
            System.err.println("Error during Nominatim geocoding for " + locationName + ": " + e.getMessage());
        }

        return null; // 검색 실패
    }
}