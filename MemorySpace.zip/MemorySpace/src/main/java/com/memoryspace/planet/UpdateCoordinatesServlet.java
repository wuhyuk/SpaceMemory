package com.memoryspace.planet;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * 특정 미디어의 위도/경도를 업데이트하는 API
 * POST /api/update-coordinates
 * Body: {"id": 1, "latitude": 37.5665, "longitude": 126.9780}
 */
@WebServlet("/api/update-coordinates")
public class UpdateCoordinatesServlet extends HttpServlet {

    private final PlanetMediaDAO planetMediaDAO = new PlanetMediaDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 응답 설정
        response.setContentType("application/json; charset=UTF-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");

        try {
            // 요청 본문 읽기
            BufferedReader reader = request.getReader();
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            
            String requestBody = sb.toString();
            System.out.println("📨 Received request: " + requestBody);

            // JSON 파싱
            JsonObject jsonRequest = gson.fromJson(requestBody, JsonObject.class);

            if (!jsonRequest.has("id") || !jsonRequest.has("latitude") || !jsonRequest.has("longitude")) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"error\": \"Missing required fields: id, latitude, longitude\"}");
                return;
            }

            Long id = jsonRequest.get("id").getAsLong();
            Double latitude = jsonRequest.get("latitude").getAsDouble();
            Double longitude = jsonRequest.get("longitude").getAsDouble();

            // DB 업데이트
            boolean success = planetMediaDAO.updateCoordinates(id, latitude, longitude);

            // 응답 생성
            JsonObject jsonResponse = new JsonObject();
            jsonResponse.addProperty("success", success);
            jsonResponse.addProperty("id", id);
            jsonResponse.addProperty("latitude", latitude);
            jsonResponse.addProperty("longitude", longitude);
            
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write(gson.toJson(jsonResponse));
            
            System.out.println("✅ Coordinates updated for id=" + id + ": " + latitude + ", " + longitude);

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doOptions(HttpServletRequest request, HttpServletResponse response) {
        // CORS preflight 요청 처리
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
        response.setStatus(HttpServletResponse.SC_OK);
    }
}