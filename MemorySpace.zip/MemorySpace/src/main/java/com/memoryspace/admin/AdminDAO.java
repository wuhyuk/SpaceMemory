// src/main/java/com/memoryspace/admin/AdminDAO.java
package com.memoryspace.admin;

import com.memoryspace.db.DBConnectionUtil;

import java.sql.*;
import java.util.*;

public class AdminDAO {

    // ---------- DTO 정의 ----------

    public static class AdminUserSummary {
        public long id;
        public String username;
        public String nickname;
        public String email;
        public String liveIn;
        public String role;
        public String status;
        public Timestamp penaltyEndAt;
        public long postCount;
        public long reportCount;
        public Timestamp lastLoginTime;
    }

    public static class AdminReportSummary {
        public long id;                 // 신고 ID (reports.id)
        public long planetId;           // 신고된 행성 ID
        public Long reporterUserId;     // 신고자 ID (nullable)
        public Long reportedUserId;     // 신고당한 유저 ID
        public String planetName;       // 행성 이름
        public String reporterNickname; // 신고자 닉네임
        public String reportedNickname; // 신고당한 닉네임
        public String reason;           // 신고 사유
        public String status;           // new / processed
    }

    public static class AdminStats {
        public long totalUsers;
        public long usedBytes;
        public long totalBytes;
        public Map<String, Long> liveInCounts = new LinkedHashMap<>();
    }

    // ---------- 사용자 + 통계 ----------

    /**
     * 사용자 목록 + 각 사용자의 게시물 수 / 신고 누적 수 / 마지막 로그인 시간을 조회.
     */
    public List<AdminUserSummary> findAllUsersWithStats() throws SQLException {
        String sql =
                "SELECT u.id, u.username, u.nickname, u.email, u.liveIn, u.role, " +
                "       u.status, u.penaltyEndAt, " +
                "       COALESCE(COUNT(DISTINCT p.id), 0) AS postCount, " +
                "       COALESCE(COUNT(DISTINCT mr.id), 0) AS reportCount, " +
                "       MAX(l.loginTime) AS lastLoginTime " +
                "FROM users u " +
                "LEFT JOIN stars s ON s.userId = u.id " +
                "LEFT JOIN planets p ON p.starId = s.id AND p.isDeleted = 0 " +
                "LEFT JOIN planet_media pm ON pm.planetId = p.id AND pm.isDeleted = 0 " +
                "LEFT JOIN media_reports mr ON mr.mediaId = pm.id " +
                "LEFT JOIN login_log l ON l.userId = u.id " +
                "GROUP BY u.id, u.username, u.nickname, u.email, u.liveIn, u.role, u.status, u.penaltyEndAt " +
                "ORDER BY u.id DESC";

        List<AdminUserSummary> result = new ArrayList<>();

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                AdminUserSummary s = new AdminUserSummary();
                s.id = rs.getLong("id");
                s.username = rs.getString("username");
                s.nickname = rs.getString("nickname");
                s.email = rs.getString("email");
                s.liveIn = rs.getString("liveIn");
                s.role = rs.getString("role");
                s.status = rs.getString("status");
                s.penaltyEndAt = rs.getTimestamp("penaltyEndAt");
                s.postCount = rs.getLong("postCount");
                s.reportCount = rs.getLong("reportCount");
                s.lastLoginTime = rs.getTimestamp("lastLoginTime");
                result.add(s);
            }
        }

        return result;
    }

    /**
     * 사용자 상태와 penaltyEndAt을 업데이트하고,
     * 변경된 사용자 정보를 담은 AdminUserSummary를 반환한다.
     * - 업데이트된 행이 없으면 null 반환.
     */
    public AdminUserSummary updateUserStatus(long userId, String status, Integer penaltyDays) throws SQLException {
        String sqlSuspended =
                "UPDATE users SET status = 'SUSPENDED', " +
                "       penaltyEndAt = DATE_ADD(NOW(), INTERVAL ? DAY) " +
                "WHERE id = ?";
        String sqlOther =
                "UPDATE users SET status = ?, penaltyEndAt = NULL " +
                "WHERE id = ?";

        try (Connection conn = DBConnectionUtil.getConnection()) {

            int updated;
            if ("SUSPENDED".equalsIgnoreCase(status) && penaltyDays != null) {
                try (PreparedStatement ps = conn.prepareStatement(sqlSuspended)) {
                    ps.setInt(1, penaltyDays);
                    ps.setLong(2, userId);
                    updated = ps.executeUpdate();
                }
            } else {
                try (PreparedStatement ps = conn.prepareStatement(sqlOther)) {
                    ps.setString(1, status.toUpperCase());
                    ps.setLong(2, userId);
                    updated = ps.executeUpdate();
                }
            }

            if (updated == 0) {
                // 해당 id의 사용자가 없음
                return null;
            }

            // 변경된 사용자 정보를 다시 읽어서 반환
            String selectSql =
                "SELECT id, username, nickname, email, liveIn, role, status, penaltyEndAt " +
                "FROM users WHERE id = ?";

            try (PreparedStatement ps = conn.prepareStatement(selectSql)) {
                ps.setLong(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        AdminUserSummary user = new AdminUserSummary();
                        user.id = rs.getLong("id");
                        user.username = rs.getString("username");
                        user.nickname = rs.getString("nickname");
                        user.email = rs.getString("email");
                        user.liveIn = rs.getString("liveIn");
                        user.role = rs.getString("role");
                        user.status = rs.getString("status");
                        user.penaltyEndAt = rs.getTimestamp("penaltyEndAt");
                        return user;
                    }
                }
            }
        }

        return null;
    }

    // ---------- 신고 관리 ----------

    /**
     * 신고 목록 조회.
     */
    public List<AdminReportSummary> findAllReports() throws SQLException {
        String sql =
                "SELECT r.id AS reportId, pm.planetId AS planetId, r.reporterUserId, " +
                "       owner.id AS reportedUserId, " +
                "       p.name AS planetName, " +
                "       ru.nickname AS reporterNickname, " +
                "       owner.id AS ownerUserId, " +
                "       owner.nickname AS reportedNickname, " +
                "       r.reason, r.status " +
                "FROM media_reports r " +
                "JOIN planet_media pm ON pm.id = r.mediaId " +
                "JOIN planets p ON p.id = pm.planetId " +
                "JOIN stars s ON s.id = p.starId " +
                "JOIN users owner ON owner.id = s.userId " +
                "LEFT JOIN users ru ON ru.id = r.reporterUserId " +
                "ORDER BY r.id DESC";

        List<AdminReportSummary> result = new ArrayList<>();

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                AdminReportSummary r = new AdminReportSummary();
                r.id = rs.getLong("reportId");
                r.planetId = rs.getLong("planetId");

                long reporterId = rs.getLong("reporterUserId");
                if (rs.wasNull()) {
                    r.reporterUserId = null;
                } else {
                    r.reporterUserId = reporterId;
                }

                long reportedId = rs.getLong("reportedUserId");
                if (rs.wasNull()) {
                    reportedId = rs.getLong("ownerUserId");
                }
                r.reportedUserId = reportedId;

                r.planetName = rs.getString("planetName");
                r.reporterNickname = rs.getString("reporterNickname");
                r.reportedNickname = rs.getString("reportedNickname");
                r.reason = rs.getString("reason");
                r.status = rs.getString("status");

                result.add(r);
            }
        }

        return result;
    }

    /**
     * 신고 상태를 processed 로 변경.
     */
    public boolean resolveReport(long reportId) throws SQLException {
        String sql = "UPDATE media_reports SET status = 'processed', processedAt = NOW() WHERE id = ?";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, reportId);
            int updated = ps.executeUpdate();
            return updated > 0;
        }
    }

    /**
     * 행성을 soft delete 하고, 해당 신고도 processed 로 변경.
     */
    public boolean deletePlanetAndResolveReport(long planetId, long reportId) throws SQLException {
        String updatePlanetSql = "UPDATE planets SET isDeleted = 1 WHERE id = ?";
        String updateReportSql = "UPDATE media_reports SET status = 'processed', processedAt = NOW() WHERE id = ?";

        try (Connection conn = DBConnectionUtil.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps1 = conn.prepareStatement(updatePlanetSql);
                 PreparedStatement ps2 = conn.prepareStatement(updateReportSql)) {

                ps1.setLong(1, planetId);
                int updatedPlanet = ps1.executeUpdate();

                ps2.setLong(1, reportId);
                int updatedReport = ps2.executeUpdate();

                if (updatedPlanet > 0 && updatedReport > 0) {
                    conn.commit();
                    return true;
                } else {
                    conn.rollback();
                    return false;
                }
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    // ---------- 통계 ----------

    public AdminStats getStats() throws SQLException {
        AdminStats stats = new AdminStats();

        String userCountSql = "SELECT COUNT(*) AS cnt FROM users";

        String mediaSizeSql =
                "SELECT COALESCE(SUM(pm.sizeBytes), 0) AS totalSize " +
                "FROM planet_media pm " +
                "JOIN planets p ON pm.planetId = p.id " +
                "WHERE p.isDeleted = 0";

        String liveInSql =
                "SELECT liveIn, COUNT(*) AS cnt " +
                "FROM users " +
                "GROUP BY liveIn " +
                "ORDER BY cnt DESC";

        try (Connection conn = DBConnectionUtil.getConnection()) {

            // 전체 사용자 수
            try (PreparedStatement ps = conn.prepareStatement(userCountSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    stats.totalUsers = rs.getLong("cnt");
                }
            }

            // 미디어 사용량
            try (PreparedStatement ps = conn.prepareStatement(mediaSizeSql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    stats.usedBytes = rs.getLong("totalSize");
                }
            }

            // 지역별 사용자 수
            try (PreparedStatement ps = conn.prepareStatement(liveInSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String liveIn = rs.getString("liveIn");
                    long cnt = rs.getLong("cnt");
                    if (liveIn == null || liveIn.isBlank()) {
                        liveIn = "미입력";
                    }
                    stats.liveInCounts.put(liveIn, cnt);
                }
            }
        }

        stats.totalBytes = 10L * 1024 * 1024 * 1024;

        return stats;
    }
}
