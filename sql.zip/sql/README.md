## 📦 File Description

| File Name | Description |
|----------|-------------|
| DataSet.sql | Data set |
| DB_Frame.sql | DB Frame (DDL) |
| trigger.sql | Location reset |
| userAdd.sql | DB User add sql |
| userDelete.sql | DB User delete sql |
| txt | SQL text file |
