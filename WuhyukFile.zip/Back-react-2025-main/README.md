Unity\_Site.zip 	  ->	Collection of React files 

MemorySpace.zip  ->	   Java project 

build.zip 		  ->	Built React code 

DataBase.txt		    ->	MySQL DataBase



11/23



지도 db와 매핑

database planet\_media 테이블에 location 항목 추가



자바 

getMapLocationsServlet.java 파일 추가

SpaRedirctFilter.java 수정



리엑트 

MapPage.jsx

MapPage.css

pakage.json 파일 leaflet.markercluster 추가



build, MemorySpace, Unity\_Site 최신화



