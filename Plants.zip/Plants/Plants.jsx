import React, { useRef, useEffect, useState } from "react";
import "./Plants.css";

export default function SpaceBackground() {
  const containerRef = useRef(null);
  const starsRef = useRef(null);
  const planetRef = useRef(null);

  const planetsRef = useRef([]);
  const labelRefs = useRef([]);
  const isPausedRef = useRef(false);
  let nextId = useRef(0);

  const [hoveredListPlanet, setHoveredListPlanet] = useState(null);
  const [planetList, setPlanetList] = useState([]);
  const [popupOpen, setPopupOpen] = useState(false);
  const [mediaPopup, setMediaPopup] = useState(null);

  const [inputName, setInputName] = useState("");
  const [inputFile, setInputFile] = useState([]);
  const [inputTag, setInputTag] = useState("");
  const [tags, setTags] = useState([]);

  const fileInputRef = useRef(null);

  const fixedPlanets = [
    { name: "Mercury", r: 6, orbit: 100, speed: 0.0016, color: "#ffaa66" },
    { name: "Venus", r: 8, orbit: 150, speed: 0.0013, color: "#ffcc99" },
    { name: "Earth", r: 10, orbit: 200, speed: 0.001, color: "#44ccff" },
    { name: "Mars", r: 15, orbit: 250, speed: 0.0009, color: "#ff8844" },
    { name: "Jupiter", r: 22, orbit: 300, speed: 0.0007, color: "#ffcc88" },
    { name: "Saturn", r: 21, orbit: 350, speed: 0.0006, color: "#ffdd99" },
    { name: "Neptune", r: 25, orbit: 400, speed: 0.0005, color: "#88aaff" },
  ];

  /* -------------------- CANVAS INIT & LOOP -------------------- */
  useEffect(() => {
    const starsCanvas = starsRef.current;
    const planetCanvas = planetRef.current;
    const container = containerRef.current;
    if (!starsCanvas || !planetCanvas || !container) return;

    const dpr = Math.max(window.devicePixelRatio || 1, 1);
    const bgCanvas = document.createElement("canvas");
    const bgCtx = bgCanvas.getContext("2d");

    let stars = [];

    function resize() {
      const { width, height } = container.getBoundingClientRect();
      [starsCanvas, planetCanvas, bgCanvas].forEach((c) => {
        c.width = Math.round(width * dpr);
        c.height = Math.round(height * dpr);
        c.style.width = `${width}px`;
        c.style.height = `${height}px`;
      });
      drawBackground();
      initStars();
    }

    function initStars() {
      const w = starsCanvas.width;
      const h = starsCanvas.height;
      const count = Math.round((w * h) / 1600);
      stars = new Array(count).fill(0).map(() => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: (Math.random() * 1.2 + 0.2) * dpr,
        twinkleSpeed: 0.003 + Math.random() * 0.007,
        phase: Math.random() * Math.PI * 2,
      }));
    }

    function drawStars() {
      const ctx = starsCanvas.getContext("2d");
      ctx.clearRect(0, 0, starsCanvas.width, starsCanvas.height);
      for (let s of stars) {
        const t = performance.now() * s.twinkleSpeed + s.phase;
        const a = 0.5 + Math.abs(Math.sin(t)) * 0.5;
        ctx.beginPath();
        ctx.fillStyle = `rgba(255,255,255,${a})`;
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    function drawBackground() {
      const w = bgCanvas.width;
      const h = bgCanvas.height;
      bgCtx.clearRect(0, 0, w, h);
      const blobs = [
        { x: 0.2 * w, y: 0.3 * h, r: 0.6 * Math.min(w, h), color: [95, 58, 255] },
        { x: 0.8 * w, y: 0.5 * h, r: 0.5 * Math.min(w, h), color: [255, 80, 175] },
        { x: 0.5 * w, y: 0.8 * Math.min(w, h), r: 0.7 * Math.min(w, h), color: [20, 200, 255] },
      ];
      blobs.forEach((b, i) => {
        const grad = bgCtx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
        const [r, g, bl] = b.color;
        grad.addColorStop(0, `rgba(${r},${g},${bl},0.45)`);
        grad.addColorStop(0.45, `rgba(${r},${g},${bl},0.18)`);
        grad.addColorStop(1, `rgba(0,0,0,0)`);
        bgCtx.globalCompositeOperation = i === 0 ? "lighter" : "screen";
        bgCtx.fillStyle = grad;
        bgCtx.fillRect(b.x - b.r, b.y - b.r, b.r * 2, b.r * 2);
      });

      const cx = w / 2;
      const cy = h / 2;
      const sunGrad = bgCtx.createRadialGradient(cx, cy, 0, cx, cy, 300 * dpr);
      sunGrad.addColorStop(0, "rgba(255,255,200,0.9)");
      sunGrad.addColorStop(0.2, "rgba(255,220,100,0.6)");
      sunGrad.addColorStop(0.6, "rgba(255,160,0,0.3)");
      sunGrad.addColorStop(1, "rgba(0,0,0,0)");
      bgCtx.globalCompositeOperation = "screen";
      bgCtx.fillStyle = sunGrad;
      bgCtx.fillRect(0, 0, w, h);
      bgCtx.globalCompositeOperation = "source-over";
    }

    function drawPlanets() {
      const ctx = planetCanvas.getContext("2d");
      const w = planetCanvas.width;
      const h = planetCanvas.height;
      const cx = w / 2;
      const cy = h / 2;
      ctx.clearRect(0, 0, w, h);
      ctx.drawImage(bgCanvas, 0, 0);

      const lightX = cx;
      const lightY = cy;

      ctx.strokeStyle = "rgba(255,255,255,0.1)";
      ctx.lineWidth = 1;
      const tiltX = 0.1;
      const tiltY = 0.7;
      const rotation = -Math.PI / 15;

      planetsRef.current.forEach((p, i) => {
        ctx.beginPath();
        ctx.ellipse(
          cx,
          cy,
          p.orbit * (1 - tiltX),
          p.orbit * (1 - tiltY),
          rotation,
          0,
          Math.PI * 2
        );
        ctx.stroke();

        if (!isPausedRef.current) p.angle += p.speed * 16;

        const x =
          cx +
          Math.cos(p.angle) * p.orbit * (1 - tiltX) * Math.cos(rotation) -
          Math.sin(p.angle) * p.orbit * (1 - tiltY) * Math.sin(rotation);

        const y =
          cy +
          Math.cos(p.angle) * p.orbit * (1 - tiltX) * Math.sin(rotation) +
          Math.sin(p.angle) * p.orbit * (1 - tiltY) * Math.cos(rotation);

        const fillColor =
          (mediaPopup && mediaPopup.planet.id !== p.id) ||
          popupOpen ||
          (hoveredListPlanet !== null && hoveredListPlanet !== p.id)
            ? "#777"
            : p.color;

        const dx = x - lightX;
        const dy = y - lightY;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;

        const highlightX = x - (dx / dist) * p.r * 0.6;
        const highlightY = y - (dy / dist) * p.r * 0.6;

        const grad = ctx.createRadialGradient(highlightX, highlightY, 0, x, y, p.r);
        grad.addColorStop(0, "rgba(255,255,255,0.9)");
        grad.addColorStop(0.25, fillColor);
        grad.addColorStop(1, "rgba(0,0,0,0.75)");
        ctx.fillStyle = grad;

        ctx.beginPath();
        ctx.arc(x, y, p.r, 0, Math.PI * 2);
        ctx.fill();

        if (labelRefs.current[i]) {
          const label = labelRefs.current[i];
          label.style.transform = `translate(${x / dpr - 20}px, ${y / dpr + p.r / dpr + 8}px)`;
        }
      });
    }

    let raf;
    function loop() {
      drawStars();
      drawPlanets();
      raf = requestAnimationFrame(loop);
    }

    resize();
    initStars();
    loop();

    window.addEventListener("resize", resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [hoveredListPlanet, mediaPopup, popupOpen]);

  /* -------------------- ADD PLANET -------------------- */
  function addPlanet(name, mediaType, mediaList, tagsArray) {
    if (planetsRef.current.length >= 7) return;

    const next = fixedPlanets[planetsRef.current.length];
    const dpr = Math.max(window.devicePixelRatio || 1, 1);

    const newPlanet = {
      id: nextId.current++,
      ...next,
      r: next.r * dpr,
      orbit: next.orbit * dpr,
      angle: Math.random() * Math.PI * 2,
      name,
      mediaType,
      mediaList,
      index: 0,
      tags: tagsArray,
      preview: mediaList?.[0]?.media || null,
    };

    planetsRef.current.push(newPlanet);
    setPlanetList((prev) => [...prev, newPlanet]);

    const label = document.createElement("div");
    label.innerText = name;
    label.className = "planet-label";
    containerRef.current.appendChild(label);
    labelRefs.current.push(label);
  }

  /* -------------------- FILE INPUT -------------------- */
  function handleFileChange(e) {
    const files = Array.from(e.target.files);
    const previewList = files.map((file) => ({
      file,
      url: URL.createObjectURL(file),
      mediaType: file.type.startsWith("video") ? "video" : "image",
    }));
    setInputFile((prev) => [...prev, ...previewList]);
    e.target.value = "";
  }

  /* -------------------- POPUP CLOSE -------------------- */
  function closeAddPopup() {
    setPopupOpen(false);
    setHoveredListPlanet(null);
    isPausedRef.current = false;

    inputFile.forEach((it) => URL.revokeObjectURL(it.url));

    setInputFile([]);
    setTags([]);
    setInputTag("");
    setInputName("");
  }

  function closeMediaPopup() {
    setMediaPopup(null);
    setHoveredListPlanet(null);
    isPausedRef.current = false;
  }

  /* -------------------- JSX RENDER -------------------- */
  return (
    <div ref={containerRef} className="space-container">
      <canvas ref={starsRef} className="stars-canvas" />
      <canvas ref={planetRef} className="planet-canvas" />

      {/* --- ADD BUTTON (첫 화면) --- */}
      {planetList.length === 0 && (
        <button
          className="add-planet-button"
          onClick={() => {
            setPopupOpen(true);
            setTags([]);
            setInputName("");
            setInputFile([]);
            setInputTag("");
            isPausedRef.current = true;
          }}
        >
          행성 추가
        </button>
      )}

      {/* --- PLANET LIST --- */}
      <div className="planet-list">
        {planetList.map((p, idx) => {
          const label = labelRefs.current[idx];
          const rect = label ? label.getBoundingClientRect() : { x: 0, y: 0 };

          return (
            <React.Fragment key={p.id}>
              {/* Hover 시만 미리보기 레이어 */}
              {hoveredListPlanet === p.id && p.preview && (
                <div
                  className="planet-preview"
                  style={{
                    top: rect.y,
                    left: rect.x,
                  }}
                >
                  {p.mediaList[0].mediaType === "image" ? (
                    <img
                      src={p.preview}
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  ) : (
                    <video
                      src={p.preview}
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      muted
                    />
                  )}
                </div>
              )}

              <div
                className="planet-list-item"
                onMouseEnter={() => {
                  if (!mediaPopup && !popupOpen) {
                    setHoveredListPlanet(p.id);
                    isPausedRef.current = true;
                  }
                }}
                onMouseLeave={() => {
                  if (!mediaPopup) {
                    setHoveredListPlanet(null);
                    isPausedRef.current = false;
                  }
                }}
                onClick={() => {
                  if (p.mediaList?.length) {
                    setMediaPopup({ planet: p, zoomIndex: null });
                    isPausedRef.current = true;
                  }
                }}
              >
                {p.name}
              </div>
            </React.Fragment>
          );
        })}

        {planetList.length > 0 && (
          <button
            className="small-add-button"
            onClick={() => {
              setPopupOpen(true);
              setTags([]);
              setInputName("");
              setInputFile([]);
              setInputTag("");
              isPausedRef.current = true;
            }}
          >
            +
          </button>
        )}
      </div>

      {/* --- ADD PLANET POPUP --- */}
      {popupOpen && (
        <div className="popup-overlay" onClick={closeAddPopup}>
          <div className="popup-panel" onClick={(e) => e.stopPropagation()}>
            <input
              type="text"
              placeholder="행성 이름 (10자 제한)"
              value={inputName}
              onChange={(e) => setInputName(e.target.value)}
              maxLength={10}
              className="input-text"
            />

            <label className="file-label">파일 선택 — 중복 파일명 허용</label>
            <input type="file" multiple accept="image/*,video/*" onChange={handleFileChange} />

            {inputFile.length > 0 && (
              <div className="preview-strip">
                {inputFile.map((it, idx) => (
                  <div className="preview-item" key={idx}>
                    {it.mediaType === "image" ? <img src={it.url} alt="" /> : <video src={it.url} muted />}
                  </div>
                ))}
              </div>
            )}

            <div className="tag-input-row">
              <input
                type="text"
                placeholder="태그 입력"
                value={inputTag}
                onChange={(e) => setInputTag(e.target.value)}
                className="input-text"
              />
              <button
                className="tag-add-btn"
                onClick={() => {
                  const t = inputTag.trim();
                  if (!t) return;
                  setTags((prev) => [...prev, t]);
                  setInputTag("");
                }}
              >
                +
              </button>
            </div>

            <div className="tag-preview">
              {tags.map((t, i) => (
                <div key={i} className="tag-item">
                  #{t}
                </div>
              ))}
            </div>

            <div className="popup-buttons">
              <button
                className="popup-add"
                onClick={() => {
                  if (!inputName) return alert("행성 이름을 입력하세요.");

                  const mediaList = inputFile.map((it) => ({ media: it.url, mediaType: it.mediaType }));

                  addPlanet(inputName, "multi", mediaList, tags);

                  setInputName("");
                  setInputFile([]);
                  setTags([]);
                  setInputTag("");

                  setPopupOpen(false);
                  isPausedRef.current = false;
                }}
              >
                추가
              </button>
              <button className="popup-close" onClick={closeAddPopup}>
                닫기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- MEDIA POPUP --- */}
      {mediaPopup && (
        <div className="media-overlay" onClick={closeMediaPopup}>
          {mediaPopup.zoomIndex === null ? (
            <div
              className="media-grid"
              onClick={(e) => e.stopPropagation()}
              style={{ position: "relative" }}
            >
              {/* + 버튼 */}
              <button
                onClick={() => fileInputRef.current.click()}
                style={{
                  position: "absolute",
                  right: "10px",
                  top: "10px",
                  zIndex: 99999,
                  width: "40px",
                  height: "40px",
                  fontSize: "26px",
                  borderRadius: "10px",
                  border: "none",
                  background: "rgba(255,255,255,0.2)",
                  cursor: "pointer",
                }}
              >
                +
              </button>

              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/*,video/*"
                style={{ display: "none" }}
                onChange={(e) => {
                  const files = Array.from(e.target.files);
                  const newItems = files.map((file) => ({
                    file,
                    media: URL.createObjectURL(file),
                    mediaType: file.type.startsWith("video") ? "video" : "image",
                  }));
                  mediaPopup.planet.mediaList.push(...newItems);
                  setMediaPopup({ ...mediaPopup });
                  e.target.value = "";
                }}
              />

              {mediaPopup.planet.mediaList.map((item, idx) => (
                <div
                  key={idx}
                  className="media-thumb"
                  onClick={() => setMediaPopup({ ...mediaPopup, zoomIndex: idx })}
                >
                  {item.mediaType === "image" ? (
                    <img src={item.media} alt="" />
                  ) : (
                    <video src={item.media} />
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="media-view-panel" onClick={(e) => e.stopPropagation()}>
              {(() => {
                const item = mediaPopup.planet.mediaList[mediaPopup.zoomIndex];
                return item.mediaType === "image" ? (
                  <img src={item.media} alt="" className="media-big" />
                ) : (
                  <video src={item.media} controls autoPlay className="media-big" />
                );
              })()}

              <div className="media-tags">
                {mediaPopup.planet.tags?.map((t, i) => (
                  <span key={i} className="media-tag">
                    #{t}
                  </span>
                ))}
              </div>

              {mediaPopup.zoomIndex !== null && (
                <div
                  style={{
                    position: "absolute",
                    bottom: "15px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    display: "flex",
                    gap: "20px",
                    zIndex: 999999,
                    background: "rgba(0,0,0,0.5)",
                    padding: "10px 20px",
                    borderRadius: "12px",
                  }}
                >
                  <button
                    style={{
                      fontSize: "28px",
                      cursor: "pointer",
                      background: "none",
                      border: "none",
                    }}
                  >
                    ❤️
                  </button>

                  <button
                    style={{
                      fontSize: "28px",
                      cursor: "pointer",
                      background: "none",
                      border: "none",
                    }}
                  >
                    ⭐
                  </button>

                  <button
                    style={{
                      fontSize: "28px",
                      cursor: "pointer",
                      background: "none",
                      border: "none",
                    }}
                  >
                    🚨
                  </button>
                </div>
              )}

              <button
                className="media-close"
                onClick={() => setMediaPopup({ ...mediaPopup, zoomIndex: null })}
              >
                ×
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}