import { useRef, useState } from "react";

export default function usePlanetSystem() {
  // -------------------- Refs --------------------
  const planetsRef = useRef([]);
  const labelRefs = useRef([]);
  const isPausedRef = useRef(false);
  const nextId = useRef(0);
  const containerRef = useRef(null);

  // -------------------- UI States --------------------
  const [planetList, setPlanetList] = useState([]);
  const [hoveredListPlanet, setHoveredListPlanet] = useState(null);

  const [popupOpen, setPopupOpen] = useState(false);
  const [mediaPopup, setMediaPopup] = useState(null);

  // -------------------- Inputs --------------------
  const [inputName, setInputName] = useState("");
  const [inputFile, setInputFile] = useState([]);
  const [inputTag, setInputTag] = useState("");
  const [tags, setTags] = useState([]);

  const fileInputRef = useRef(null);

  // -------------------- Fixed Planet Settings --------------------
  const fixedPlanets = [
    { name: "Mercury", r: 6, orbit: 100, speed: 0.0016, color: "#ffaa66" },
    { name: "Venus", r: 8, orbit: 150, speed: 0.0013, color: "#ffcc99" },
    { name: "Earth", r: 10, orbit: 200, speed: 0.001, color: "#44ccff" },
    { name: "Mars", r: 15, orbit: 250, speed: 0.0009, color: "#ff8844" },
    { name: "Jupiter", r: 22, orbit: 300, speed: 0.0007, color: "#ffcc88" },
    { name: "Saturn", r: 21, orbit: 350, speed: 0.0006, color: "#ffdd99" },
    { name: "Neptune", r: 25, orbit: 400, speed: 0.0005, color: "#88aaff" },
  ];

  // -------------------- Add Planet --------------------
  function addPlanet(name, mediaList, tagsArray) {
    if (planetsRef.current.length >= 7) return;

    const next = fixedPlanets[planetsRef.current.length];
    const dpr = Math.max(window.devicePixelRatio || 1, 1);

    // ---------------------------------------------------------
    // ★ 변경됨 — mediaList의 구조 통일 (media → url 로 통일)
    // ---------------------------------------------------------
    const normalizedMediaList = mediaList.map((it) => ({
      url: it.url,             // ★ 구조 통일
      mediaType: it.mediaType, // image / video
    }));

    const newPlanet = {
      id: nextId.current++,
      ...next,
      r: next.r * dpr,
      orbit: next.orbit * dpr,
      angle: Math.random() * Math.PI * 2,
      name,
      mediaList: normalizedMediaList,   // ★ 통일된 리스트 사용
      tags: tagsArray,
      preview: normalizedMediaList?.[0]?.url || null,  // ★ url 사용
      screenX: 0, // ★ PlanetPreview 위치 계산 값
      screenY: 0, // ★ PlanetPreview 위치 계산 값
    };

    planetsRef.current.push(newPlanet);
    setPlanetList([...planetsRef.current]);
  }

  // -------------------- File Upload Preview --------------------
  function handleFileChange(e) {
    const files = Array.from(e.target.files);

    const previewList = files.map((file) => ({
      file,
      url: URL.createObjectURL(file),          // ★ url 로 저장
      mediaType: file.type.startsWith("video") ? "video" : "image",
    }));

    setInputFile((prev) => [...prev, ...previewList]);
    e.target.value = "";
  }

  // -------------------- Close Add Popup --------------------
  function closeAddPopup() {
    setPopupOpen(false);
    setHoveredListPlanet(null);
    isPausedRef.current = false;

    setInputFile([]);
    setTags([]);
    setInputTag("");
    setInputName("");
  }

  // -------------------- Close Media Popup --------------------
  function closeMediaPopup() {
    setMediaPopup(null);
    setHoveredListPlanet(null);
    isPausedRef.current = false;
  }

  return {
    containerRef,

    // refs
    planetsRef,
    labelRefs,
    isPausedRef,
    nextId,

    // states
    planetList,
    hoveredListPlanet,
    popupOpen,
    mediaPopup,

    // inputs
    inputName,
    inputFile,
    inputTag,
    tags,
    fileInputRef,

    // setters
    setPlanetList,
    setHoveredListPlanet,
    setPopupOpen,
    setMediaPopup,
    setInputName,
    setInputFile,
    setInputTag,
    setTags,

    // functions
    addPlanet,
    handleFileChange,
    closeAddPopup,
    closeMediaPopup,
  };
}
