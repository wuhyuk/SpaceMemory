import React from "react";

export default function MediaPopup({ system }) {
  const { mediaPopup, setMediaPopup, closeMediaPopup, fileInputRef } = system;

  if (!mediaPopup) return null;

  const planet = mediaPopup.planet;
  const zoomIndex = mediaPopup.zoomIndex;

  return (
    <div className="media-overlay" onClick={closeMediaPopup}>
      {zoomIndex === null ? (
        /* ============================
           GRID VIEW
        ============================ */
        <div
          className="media-grid"
          onClick={(e) => e.stopPropagation()}
          style={{ position: "relative" }}
        >
          {/* + 버튼 */}
          <button
            className="media-add-button"
            onClick={() => fileInputRef.current.click()}
          >
            +
          </button>


          {/* 숨겨진 input */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,video/*"
            style={{ display: "none" }}
            onChange={(e) => {
              const files = Array.from(e.target.files);

              // ★ 변경됨 — 구조 통일: 모든 미디어는 { url, mediaType }
              const newItems = files.map((file) => ({
                url: URL.createObjectURL(file),               // ★ media → url
                mediaType: file.type.startsWith("video") ? "video" : "image",
              }));

              planet.mediaList.push(...newItems);
              setMediaPopup({ ...mediaPopup }); // 리렌더
              e.target.value = "";
            }}
          />

          {/* 썸네일 렌더 */}
          {planet.mediaList.map((item, idx) => (
            <div
              key={idx}
              className="media-thumb"
              onClick={() => setMediaPopup({ planet, zoomIndex: idx })}
            >
              {/* ★ 변경됨 — item.media → item.url */}
              {item.mediaType === "image" ? (
                <img src={item.url} alt="" />
              ) : (
                <video src={item.url} muted />
              )}
            </div>
          ))}
        </div>
      ) : (
        /* ============================
           ZOOM VIEW
        ============================ */
        <div className="media-view-panel" onClick={(e) => e.stopPropagation()}>
          {(() => {
            const item = planet.mediaList[zoomIndex];

            // ★ 변경됨 — item.media → item.url
            return item.mediaType === "image" ? (
              <img src={item.url} alt="" className="media-big" />
            ) : (
              <video src={item.url} controls autoPlay className="media-big" />
            );
          })()}

          {/* 태그 목록 */}
          <div className="media-tags">
            {planet.tags?.map((t, i) => (
              <span key={i} className="media-tag">
                #{t}
              </span>
            ))}
          </div>

          {/* 좋아요/별/신고 */}
          <div
            style={{
              position: "absolute",
              bottom: "15px",
              left: "50%",
              transform: "translateX(-50%)",
              display: "flex",
              gap: "20px",
              zIndex: 999999,
              background: "rgba(0,0,0,0.5)",
              padding: "10px 20px",
              borderRadius: "12px",
            }}
          >
            <button
              style={{
                fontSize: "28px",
                cursor: "pointer",
                background: "none",
                border: "none",
              }}
            >
              ❤️
            </button>

            <button
              style={{
                fontSize: "28px",
                cursor: "pointer",
                background: "none",
                border: "none",
              }}
            >
              ⭐
            </button>

            <button
              style={{
                fontSize: "28px",
                cursor: "pointer",
                background: "none",
                border: "none",
              }}
            >
              🚨
            </button>
          </div>

          {/* 확대 → 그리드로 돌아가기 */}
          <button
            className="media-close"
            onClick={() => setMediaPopup({ planet, zoomIndex: null })}
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}
