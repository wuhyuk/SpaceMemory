import React from "react";
import { createPortal } from "react-dom";

export default function PlanetPreview({ x, y, media, planet }) {
  const style = {
    position: "fixed",
    left: `${x}px`,
    top: `${y}px`,
    width: "130px",
    height: "130px",
    zIndex: 3000,
    pointerEvents: "none",
    background: "#000",
    border: "2px solid #7b7bff",
    borderRadius: "12px",
    boxShadow: "0 0 12px #7b7bff",
  };

  const content =
    media.mediaType === "image" ? (
      <img
        src={media.url || media.media}
        style={{ width: "100%", height: "100%", objectFit: "contain" }}
        alt=""
      />
    ) : (
      <video
        src={media.url || media.media}
        autoPlay
        loop
        muted
        style={{ width: "100%", height: "100%", objectFit: "contain" }}
      />
    );

  return createPortal(
    <div className="planet-preview" style={style}>
      {content}
    </div>,
    document.body
  );
}
