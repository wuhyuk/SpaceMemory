// PlanetList.jsx
// 변경요약:
// - preview 위치는 리스트 요소(rect)가 아니라 행성의 screenX/screenY를 기준으로 함.
// - preview 렌더 조건에 screenX 존재 여부 체크 추가 (NaN 방지).
// - hover enter/leave 로직과 popupOpen/mediaPopup 체크 유지.

import React, { useRef } from "react";
import PlanetPreview from "./PlanetPreview";

export default function PlanetList({ system }) {
  const {
    planetList,
    hoveredListPlanet,
    setHoveredListPlanet,

    popupOpen,
    mediaPopup,

    setMediaPopup,
    setPopupOpen,
    setInputName,
    setInputFile,
    setInputTag,
    setTags,

    isPausedRef,
  } = system;

  const itemRefs = useRef([]);

  return (
    <>
      {/* 행성 없을 때 중앙 추가 버튼 */}
      {planetList.length === 0 && (
        <button
          className="add-planet-button"
          onClick={() => {
            setPopupOpen(true);
            setTags([]);
            setInputName("");
            setInputFile([]);
            setInputTag("");
            isPausedRef.current = true;
          }}
        >
          행성 추가
        </button>
      )}

      <div className="planet-list">
        {planetList.map((p, idx) => {
          // 디버그: 행성의 screen 좌표가 들어오는지 확인
          // (콘솔이 너무 지저분하면 주석 처리 가능)
          console.log("PlanetList: p.id", p.id, "screenX", p.screenX, "screenY", p.screenY);
          const itemRef = itemRefs.current[idx];
          const rect = itemRef ? itemRef.getBoundingClientRect() : null;
          return (
            <React.Fragment key={p.id}>
              {/* Hover 상태이고 screen 좌표가 준비되어 있으면 preview 렌더 */}
              {hoveredListPlanet === p.id &&
                !popupOpen &&
                !mediaPopup &&
                rect &&
                p.mediaList.length > 0 && (
                    <PlanetPreview
                      x={p.screenX + 40}
                      y={p.screenY - 25}
                      media={p.mediaList[0]}
                      planet={p}
                    />
                )}

              <div
                className="planet-list-item"
                ref={(el) => (itemRefs.current[idx] = el)}
                onMouseEnter={() => {
                  if (!popupOpen && !mediaPopup) {
                    setHoveredListPlanet(p.id);
                    isPausedRef.current = true;
                  }
                }}
                onMouseLeave={() => {
                  if (!mediaPopup) {
                    setHoveredListPlanet(null);
                    isPausedRef.current = false;
                  }
                }}
                onClick={() => {
                  if (p.mediaList?.length > 0) {
                    setMediaPopup({ planet: p, zoomIndex: null });
                    isPausedRef.current = true;
                  }
                }}
              >
                {p.name}
              </div>
            </React.Fragment>
          );
        })}

        {/* 작은 + 버튼 */}
        {planetList.length > 0 && (
          <button
            className="small-add-button"
            onClick={() => {
              setPopupOpen(true);
              setTags([]);
              setInputName("");
              setInputFile([]);
              setInputTag("");
              isPausedRef.current = true;
            }}
          >
            +
          </button>
        )}
      </div>
    </>
  );
}
