import React from "react";

export default function AddPlanetPopup({ system }) {
  const {
    inputName,
    setInputName,
    inputFile,
    setInputFile,
    tags,
    setTags,
    inputTag,
    setInputTag,
    handleFileChange,
    closeAddPopup,
    addPlanet,
    isPausedRef,
  } = system;

  return (
    <div className="popup-overlay" onClick={closeAddPopup}>
      <div className="popup-panel" onClick={(e) => e.stopPropagation()}>
        
        {/* 행성 이름 */}
        <input
          type="text"
          placeholder="행성 이름 (10자 제한)"
          value={inputName}
          onChange={(e) => setInputName(e.target.value)}
          maxLength={10}
          className="input-text"
        />

        {/* 파일 업로드 */}
        <label className="file-label">파일 선택 — 중복 파일명 허용</label>

        {/* 숨겨진 파일 input */}
        <input
          id="file-upload-hidden"
          type="file"
          multiple
          accept="image/*,video/*"
          onChange={handleFileChange}
          style={{ display: "none" }}
        />

        {/* ★ 스타일된 버튼 */}
        <button
          className="file-select-button"
          onClick={() => document.getElementById("file-upload-hidden").click()}
        >
          파일 선택
        </button>


        {/* 파일 미리보기 */}
        {inputFile.length > 0 && (
          <div className="preview-strip">
            {inputFile.map((it, idx) => (
              <div className="preview-item" key={idx}>
                {it.mediaType === "image" ? (
                  <img src={it.url} alt="" />
                ) : (
                  <video src={it.url} muted />
                )}
              </div>
            ))}
          </div>
        )}

        {/* 태그 입력 */}
        <div className="tag-input-row">
          <input
            type="text"
            placeholder="태그 입력"
            value={inputTag}
            onChange={(e) => setInputTag(e.target.value)}
            className="input-text"
          />
          <button
            className="tag-add-btn"
            onClick={() => {
              const t = inputTag.trim();
              if (!t) return;
              setTags((prev) => [...prev, t]);
              setInputTag("");
            }}
          >
            +
          </button>
        </div>

        {/* 태그 미리보기 */}
        <div className="tag-preview">
          {tags.map((t, i) => (
            <div key={i} className="tag-item">
              #{t}
            </div>
          ))}
        </div>

        {/* 버튼 */}
        <div className="popup-buttons">
          <button
            className="popup-add"
            onClick={() => {
              if (!inputName) return alert("행성 이름을 입력하세요.");
              if (inputFile.length === 0) return alert("파일을 하나 이상 선택하세요.");

              const mediaList = inputFile.map((it) => ({
                url: it.url,          // ← ★ PlanetPreview와 동일한 구조
                mediaType: it.mediaType,
              }));

              addPlanet(inputName, mediaList, tags);

              // 초기화
              setInputName("");
              setInputFile([]);
              setTags([]);
              setInputTag("");

              isPausedRef.current = false;
              system.setPopupOpen(false);
            }}
          >
            추가
          </button>

          <button className="popup-close" onClick={closeAddPopup}>
            닫기
          </button>
        </div>
      </div>
    </div>
  );
}
