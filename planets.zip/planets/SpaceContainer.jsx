import React from "react";
import "./Planets.css";

import usePlanetSystem from "./usePlanetSystem";

// 캔버스/리스트/팝업 컴포넌트
import CanvasLayer from "./CanvasLayer";
import PlanetList from "./PlanetList";
import AddPlanetPopup from "./AddPlanetPopup";
import MediaPopup from "./MediaPopup";

export default function SpaceContainer() {
  const system = usePlanetSystem();

  return (
    <div ref={system.containerRef} className="space-container">
      {/* 캔버스 영역 (별 + 행성) */}
      <CanvasLayer system={system} />

      {/* 행성 리스트 */}
      <PlanetList system={system} />

      {/* 행성 추가 팝업 */}
      {system.popupOpen && <AddPlanetPopup system={system} />}

      {/* 미디어 팝업 */}
      {system.mediaPopup && <MediaPopup system={system} />}
    </div>
  );
}
