import { useEffect,useState } from "react";
import SpaceContainer from "./SpaceContainer";

function Planets(){
  return(
    <div className="Planets">
      <SpaceContainer />
    </div>
  )
}

export default Planets;